
import React from 'react';
import { PlayerConfig, DEFAULT_CONFIG } from '../../../types';

interface ImpersonateControlsProps {
    setConfig: React.Dispatch<React.SetStateAction<PlayerConfig>>;
    onResetToBase?: () => void;
}

type ImpersonatePreset = { name: string; role: string; color: string; config: Partial<PlayerConfig> };
type EmbellishmentStage = 1 | 2 | 3;
type HumanoidPresetStats = {
    health: number;
    chakra: number;
    attack: number;
    defense: number;
    evasion: number;
    dexterity: number;
};

const HUMANOID_PRESET_STATS: Record<string, HumanoidPresetStats> = {
    Archer: { health: 90, chakra: 40, attack: 18, defense: 8, evasion: 14, dexterity: 16 },
    Assassin: { health: 80, chakra: 50, attack: 22, defense: 6, evasion: 20, dexterity: 18 },
    Bandit: { health: 100, chakra: 30, attack: 12, defense: 8, evasion: 8, dexterity: 10 },
    Berserker: { health: 160, chakra: 40, attack: 25, defense: 6, evasion: 4, dexterity: 8 },
    Mage: { health: 85, chakra: 100, attack: 20, defense: 5, evasion: 10, dexterity: 10 },
    Rogue: { health: 95, chakra: 60, attack: 16, defense: 7, evasion: 16, dexterity: 15 },
    Warlock: { health: 100, chakra: 80, attack: 22, defense: 6, evasion: 12, dexterity: 12 },
    Paladin: { health: 140, chakra: 60, attack: 18, defense: 16, evasion: 4, dexterity: 9 },
    Ranger: { health: 105, chakra: 50, attack: 16, defense: 10, evasion: 12, dexterity: 14 },
    Monk: { health: 115, chakra: 90, attack: 20, defense: 8, evasion: 18, dexterity: 17 },
    Cleric: { health: 110, chakra: 70, attack: 14, defense: 12, evasion: 6, dexterity: 10 },
    Sentinel: { health: 130, chakra: 40, attack: 12, defense: 22, evasion: 1, dexterity: 7 },
    Knight: { health: 150, chakra: 40, attack: 16, defense: 18, evasion: 2, dexterity: 8 },
    'City Guard': { health: 120, chakra: 30, attack: 14, defense: 14, evasion: 5, dexterity: 9 },
    Barbarian: { health: 155, chakra: 20, attack: 24, defense: 7, evasion: 6, dexterity: 9 },
    Bard: { health: 95, chakra: 80, attack: 12, defense: 8, evasion: 12, dexterity: 14 },
    Druid: { health: 105, chakra: 95, attack: 18, defense: 9, evasion: 10, dexterity: 11 },
    Sorcerer: { health: 80, chakra: 110, attack: 24, defense: 4, evasion: 10, dexterity: 12 },
    Wizard: { health: 75, chakra: 120, attack: 22, defense: 4, evasion: 8, dexterity: 11 },
    Blacksmith: { health: 135, chakra: 20, attack: 18, defense: 14, evasion: 3, dexterity: 8 },
    Shopkeeper: { health: 85, chakra: 25, attack: 8, defense: 6, evasion: 7, dexterity: 10 }
};

const NPC_PRESETS: ImpersonatePreset[] = [
    {
        name: "City Guard",
        role: "Defender",
        color: "bg-blue-600",
        config: {
            bodyType: 'male', bodyVariant: 'average', skinColor: '#ffdbac', hairStyle: 'crew', hairColor: '#3e2723',
            shirtColor: '#4a3728', pantsColor: '#718096', bootsColor: '#8d6e63',
            equipment: { ...DEFAULT_CONFIG.equipment, helm: true, shoulders: true, shirt: true, pants: true, shoes: true, quiltedArmor: true, bracers: true, belt: true },
            selectedItem: 'Halberd', weaponStance: 'shoulder'
        }
    },
    {
        name: "Knight",
        role: "Tank",
        color: "bg-slate-500",
        config: {
            bodyType: 'male', bodyVariant: 'muscular', outfit: 'warrior', skinColor: '#e0c8a8',
            shirtColor: '#37474f', pantsColor: '#263238', bootsColor: '#1a1a1a', hairStyle: 'bald',
            equipment: { ...DEFAULT_CONFIG.equipment, helm: true, shoulders: true, shield: true, shirt: true, pants: true, shoes: true, plateMail: true, bracers: true, cape: true, belt: true },
            selectedItem: 'Sword', weaponStance: 'side'
        }
    },
    {
        name: "Assassin",
        role: "Stealth",
        color: "bg-red-900",
        config: {
            bodyType: 'male', bodyVariant: 'slim', outfit: 'warrior', skinColor: '#d7ccc8',
            shirtColor: '#000000', pantsColor: '#000000', hoodColor: '#000000', hairStyle: 'bald',
            equipment: { ...DEFAULT_CONFIG.equipment, shoulders: true, shirt: true, pants: true, shoes: true, mask: true, hood: true, bracers: true, belt: true },
            selectedItem: 'Knife', weaponStance: 'side'
        }
    },
    {
        name: "Ranger",
        role: "Ranged",
        color: "bg-emerald-600",
        config: {
            bodyType: 'female', bodyVariant: 'slim', outfit: 'peasant', skinColor: '#ffe4c4',
            shirtColor: '#2e8b57', pantsColor: '#556b2f', bootsColor: '#8b4513', hoodColor: '#2e8b57', robeColor: '#2e8b57', hairStyle: 'crew', hairColor: '#8b4513',
            equipment: { ...DEFAULT_CONFIG.equipment, hood: true, leatherArmor: true, shirt: true, pants: true, shoes: true, bracers: true, cape: true, belt: true },
            selectedItem: 'Bow', weaponStance: 'side'
        }
    },
    {
        name: "Mage",
        role: "Caster",
        color: "bg-indigo-600",
        config: {
            bodyType: 'female', bodyVariant: 'slim', outfit: 'noble', skinColor: '#d4c4b0',
            shirtColor: '#1a0a2e', pantsColor: '#0d0518', robeColor: '#1a0a2e', robeTrimColor: '#6b21a8',
            mageHatColor: '#1a0a2e', mageHatBandColor: '#9333ea', hairStyle: 'bald',
            mageHatY: 0.08,
            equipment: { ...DEFAULT_CONFIG.equipment, robe: true, mageHat: true, shoulders: true, shirt: true, pants: true, shoes: true, cape: true, belt: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Cleric",
        role: "Healer",
        color: "bg-yellow-500",
        config: {
            bodyType: 'female', bodyVariant: 'average', outfit: 'noble', skinColor: '#ffe4c4',
            shirtColor: '#f5f5f5', pantsColor: '#dcdcdc', bootsColor: '#d4af37', robeColor: '#f5f5f5', robeTrimColor: '#ffd700',
            mageHatColor: '#f5f5f5', mageHatBandColor: '#ffd700', hairStyle: 'crew', hairColor: '#ffd700',
            equipment: { ...DEFAULT_CONFIG.equipment, robe: true, mageHat: true, shirt: true, pants: true, shoes: true, cape: true, belt: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Berserker",
        role: "Damage",
        color: "bg-orange-700",
        config: {
            bodyType: 'male', bodyVariant: 'heavy', outfit: 'warrior', skinColor: '#c9a882',
            shirtColor: '#8b0000', pantsColor: '#4a2020', bootsColor: '#2d1a1a', hairStyle: 'bald', hairColor: '#8b0000',
            equipment: { ...DEFAULT_CONFIG.equipment, heavyLeatherArmor: true, shirt: true, pants: true, shoes: true, bracers: true, belt: true },
            selectedItem: 'Halberd', weaponStance: 'shoulder'
        }
    },
    {
        name: "Barbarian",
        role: "Bruiser",
        color: "bg-amber-800",
        config: {
            bodyType: 'male', bodyVariant: 'muscular', outfit: 'warrior', skinColor: '#c68642',
            shirtColor: '#7a4a27', pantsColor: '#5a2f15', bootsColor: '#2f1b12', hairStyle: 'crew', hairColor: '#3b2413',
            equipment: { ...DEFAULT_CONFIG.equipment, shoulders: true, heavyLeatherArmor: true, shirt: true, pants: true, shoes: true, bracers: true, belt: true },
            selectedItem: 'Axe', weaponStance: 'side'
        }
    },
    {
        name: "Bard",
        role: "Support",
        color: "bg-fuchsia-700",
        config: {
            bodyType: 'female', bodyVariant: 'slim', outfit: 'noble', skinColor: '#f1c27d',
            shirtColor: '#7b2cbf', pantsColor: '#3c1642', bootsColor: '#4a2c2a', robeColor: '#6a1b9a', robeTrimColor: '#f4d35e',
            hairStyle: 'crew', hairColor: '#3e2723',
            equipment: { ...DEFAULT_CONFIG.equipment, robe: true, shirt: true, pants: true, shoes: true, bracers: true, cape: true, belt: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Druid",
        role: "Nature",
        color: "bg-lime-700",
        config: {
            bodyType: 'female', bodyVariant: 'slim', outfit: 'peasant', skinColor: '#d9b38c',
            shirtColor: '#556b2f', pantsColor: '#3f5d32', bootsColor: '#5c4033', robeColor: '#6b8e23', robeTrimColor: '#c2b280',
            hoodColor: '#4f772d', hairStyle: 'crew', hairColor: '#6f4e37',
            equipment: { ...DEFAULT_CONFIG.equipment, hood: true, robe: true, shirt: true, pants: true, shoes: true, cape: true, belt: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Rogue",
        role: "Skirmisher",
        color: "bg-zinc-700",
        config: {
            bodyType: 'male', bodyVariant: 'slim', outfit: 'warrior', skinColor: '#d4a574',
            shirtColor: '#1a1a1a', pantsColor: '#0d0d0d', bootsColor: '#0a0a0a', hoodColor: '#1a1a1a', hairStyle: 'bald',
            equipment: { ...DEFAULT_CONFIG.equipment, hood: true, mask: true, leatherArmor: true, shirt: true, pants: true, shoes: true, bracers: true, cape: true, belt: true },
            selectedItem: 'Knife', weaponStance: 'side'
        }
    },
    {
        name: "Sorcerer",
        role: "Arcane",
        color: "bg-sky-700",
        config: {
            bodyType: 'female', bodyVariant: 'slim', outfit: 'noble', skinColor: '#d8c0a8',
            shirtColor: '#1f3c88', pantsColor: '#14213d', bootsColor: '#1b1b2f', robeColor: '#1f3c88', robeTrimColor: '#7dd3fc',
            mageHatColor: '#1f3c88', mageHatBandColor: '#f8fafc', hairStyle: 'crew', hairColor: '#1b1b1b',
            equipment: { ...DEFAULT_CONFIG.equipment, robe: true, mageHat: true, shirt: true, pants: true, shoes: true, bracers: true, cape: true, belt: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Wizard",
        role: "Scholar",
        color: "bg-cyan-800",
        config: {
            bodyType: 'male', bodyVariant: 'slim', outfit: 'noble', skinColor: '#e0c4a8',
            shirtColor: '#1e293b', pantsColor: '#0f172a', bootsColor: '#111827', robeColor: '#334155', robeTrimColor: '#cbd5e1',
            mageHatColor: '#334155', mageHatBandColor: '#93c5fd', hairStyle: 'bald', hairColor: '#d6d3d1',
            equipment: { ...DEFAULT_CONFIG.equipment, robe: true, mageHat: true, shirt: true, pants: true, shoes: true, bracers: true, cape: true, belt: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Blacksmith",
        role: "Civilian",
        color: "bg-orange-900",
        config: {
            bodyType: 'male', bodyVariant: 'muscular', skinColor: '#ffdbac', hairStyle: 'bald',
            shirtColor: '#000000', pantsColor: '#808080', bootsColor: '#000000', apronColor: '#4e342e', apronDetailColor: '#3e2723',
            equipment: { ...DEFAULT_CONFIG.equipment, blacksmithApron: true, shirt: true, pants: true, shoes: true, belt: true },
            selectedItem: 'Pickaxe', weaponStance: 'side'
        }
    },
    {
        name: "Shopkeeper",
        role: "Civilian",
        color: "bg-purple-800",
        config: {
            bodyType: 'female', bodyVariant: 'average', outfit: 'noble', hairStyle: 'crew',
            shirtColor: '#6a4c93', pantsColor: '#4a2f7a',
            equipment: { ...DEFAULT_CONFIG.equipment, robe: true, cape: true, belt: true, shirt: true, pants: true, shoes: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Monk",
        role: "Brawler",
        color: "bg-amber-600",
        config: {
            bodyType: 'male', bodyVariant: 'average', outfit: 'noble', skinColor: '#d2b48c',
            shirtColor: '#ff8c00', pantsColor: '#8b4513', bootsColor: '#654321', robeColor: '#ff8c00', robeTrimColor: '#8b0000',
            hairStyle: 'bald',
            equipment: { ...DEFAULT_CONFIG.equipment, robe: true, belt: true, shirt: true, pants: true, shoes: false },
            selectedItem: null, weaponStance: 'side'
        }
    }
];

const CREATURE_MORPHS = {
    demon: {
        torsoWidth: 0.88, torsoHeight: 1.0, armScale: 1.2, legScale: 0.88,
        headScale: 1.02, neckHeight: 0.55, neckThickness: 0.78,
        footLength: 1.1, footWidth: 1.0, toeSpread: 1.32,
        chinSize: 0.86, chinLength: 1.22, chinForward: 0.06, noseForward: 0.09,
        buttScale: 0.58
    },
    arachnid: {
        torsoWidth: 0.72, torsoHeight: 0.8, armScale: 1.28, legScale: 1.25,
        headScale: 0.78, neckHeight: 0.48, neckThickness: 0.55,
        footLength: 1.28, footWidth: 0.72, toeSpread: 1.35,
        chinSize: 0.5, chinLength: 0.75, buttScale: 0.55
    },
    predator: {
        torsoWidth: 0.95, torsoHeight: 0.86, armScale: 1.2, legScale: 1.22,
        headScale: 0.82, neckHeight: 0.52, neckThickness: 0.9,
        footLength: 1.22, footWidth: 0.95, toeSpread: 1.32,
        chinSize: 0.58, chinLength: 0.82, buttScale: 0.7
    },
    brute: {
        torsoWidth: 1.45, torsoHeight: 0.88, armScale: 1.02, legScale: 0.86,
        headScale: 0.86, neckHeight: 0.5, neckThickness: 1.02,
        footLength: 0.96, footWidth: 1.26, toeSpread: 0.82,
        chinSize: 0.62, chinLength: 0.88, buttScale: 1.2
    },
    titan: {
        torsoWidth: 1.34, torsoHeight: 1.02, armScale: 1.18, legScale: 1.0,
        headScale: 0.84, neckHeight: 0.54, neckThickness: 0.98,
        footLength: 1.2, footWidth: 1.15, toeSpread: 0.95,
        chinSize: 0.56, chinLength: 0.86, buttScale: 1.05
    },
    watcher: {
        torsoWidth: 0.78, torsoHeight: 0.74, armScale: 0.88, legScale: 1.34,
        headScale: 0.9, neckHeight: 0.95, neckThickness: 0.58,
        footLength: 1.3, footWidth: 0.7, toeSpread: 1.45,
        chinSize: 0.54, chinLength: 0.72, buttScale: 0.5
    },
    grazer: {
        torsoWidth: 0.86, torsoHeight: 0.82, armScale: 0.92, legScale: 1.38,
        headScale: 0.84, neckHeight: 1.0, neckThickness: 0.62,
        footLength: 1.36, footWidth: 0.74, toeSpread: 1.3,
        chinSize: 0.52, chinLength: 0.76, buttScale: 0.58
    },
    fowl: {
        torsoWidth: 0.74, torsoHeight: 0.7, armScale: 0.74, legScale: 1.25,
        headScale: 0.92, neckHeight: 1.08, neckThickness: 0.5,
        footLength: 1.22, footWidth: 0.62, toeSpread: 1.5,
        chinSize: 0.48, chinLength: 0.68, buttScale: 0.45
    },
    forager: {
        torsoWidth: 1.22, torsoHeight: 0.78, armScale: 0.82, legScale: 0.92,
        headScale: 0.86, neckHeight: 0.56, neckThickness: 0.9,
        footLength: 0.9, footWidth: 1.06, toeSpread: 0.88,
        chinSize: 0.5, chinLength: 0.72, buttScale: 1.08
    },
    wool: {
        torsoWidth: 1.34, torsoHeight: 0.86, armScale: 0.76, legScale: 0.88,
        headScale: 0.82, neckHeight: 0.54, neckThickness: 0.92,
        footLength: 0.92, footWidth: 1.12, toeSpread: 0.9,
        chinSize: 0.5, chinLength: 0.7, buttScale: 1.25
    },
    reptile: {
        torsoWidth: 0.9, torsoHeight: 0.78, armScale: 0.82, legScale: 0.98,
        headScale: 0.88, neckHeight: 0.62, neckThickness: 0.66,
        footLength: 1.16, footWidth: 0.8, toeSpread: 1.42,
        chinSize: 0.56, chinLength: 0.84, buttScale: 0.62
    },
    mount: {
        torsoWidth: 1.18, torsoHeight: 0.82, armScale: 0.92, legScale: 1.45,
        headScale: 0.9, neckHeight: 0.98, neckThickness: 0.95,
        footLength: 1.55, footWidth: 0.92, toeSpread: 0.68,
        chinSize: 0.6, chinLength: 1.2, buttScale: 1.05
    }
} as const;

const NON_HUMANOID_PRESETS: ImpersonatePreset[] = [
    {
        name: "Imp",
        role: "Demon",
        color: "bg-red-700",
        config: {
            ...CREATURE_MORPHS.demon,
            impersonationModel: 'imp',
            bodyType: 'male', bodyVariant: 'slim', outfit: 'naked', skinColor: '#9a1730',
            eyeColor: '#f6ad2f', scleraColor: '#f4d6a0', pupilColor: '#170808', lipColor: '#4d0d1b',
            hairStyle: 'bald',
            shirtColor: '#541022', pantsColor: '#2b0a14', bootsColor: '#1b070d',
            equipment: { ...DEFAULT_CONFIG.equipment },
            selectedItem: 'Sword', weaponStance: 'side'
        }
    },
    {
        name: "Spider",
        role: "Arachnid",
        color: "bg-zinc-900",
        config: {
            ...CREATURE_MORPHS.arachnid,
            impersonationModel: 'spider',
            bodyType: 'male', bodyVariant: 'slim', outfit: 'naked', skinColor: '#173f67',
            hairStyle: 'bald',
            shirtColor: '#101010', pantsColor: '#060606', bootsColor: '#080808',
            equipment: { ...DEFAULT_CONFIG.equipment, mask: true, hood: true, gloves: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Wolf",
        role: "Predator",
        color: "bg-slate-600",
        config: {
            ...CREATURE_MORPHS.predator,
            impersonationModel: 'wolf',
            bodyType: 'male', bodyVariant: 'muscular', outfit: 'naked', skinColor: '#8a8f98',
            hairStyle: 'crew', hairColor: '#4b5563',
            shirtColor: '#4b5563', pantsColor: '#374151', bootsColor: '#1f2937',
            equipment: { ...DEFAULT_CONFIG.equipment, hood: true, gloves: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Bear",
        role: "Brute",
        color: "bg-amber-900",
        config: {
            ...CREATURE_MORPHS.brute,
            impersonationModel: 'bear',
            bodyType: 'male', bodyVariant: 'heavy', outfit: 'naked', skinColor: '#6b3f1f',
            hairStyle: 'crew', hairColor: '#3f2a18',
            shirtColor: '#5a3b1a', pantsColor: '#3b2a18', bootsColor: '#2b1f14',
            equipment: { ...DEFAULT_CONFIG.equipment, heavyLeatherArmor: true, gloves: true },
            selectedItem: null, weaponStance: 'shoulder'
        }
    },
    {
        name: "Yeti",
        role: "Titan",
        color: "bg-slate-300",
        config: {
            ...CREATURE_MORPHS.titan,
            impersonationModel: 'yeti',
            bodyType: 'male', bodyVariant: 'heavy', outfit: 'naked', skinColor: '#dce7ef',
            hairStyle: 'crew', hairColor: '#f8fafc',
            shirtColor: '#cbd5e1', pantsColor: '#94a3b8', bootsColor: '#64748b',
            equipment: { ...DEFAULT_CONFIG.equipment, heavyLeatherArmor: true, hood: true, gloves: true },
            selectedItem: null, weaponStance: 'shoulder'
        }
    },
    {
        name: "Owl",
        role: "Watcher",
        color: "bg-amber-500",
        config: {
            ...CREATURE_MORPHS.watcher,
            impersonationModel: 'owl',
            bodyType: 'female', bodyVariant: 'slim', outfit: 'naked', skinColor: '#e2c38b',
            hairStyle: 'crew', hairColor: '#7c5a34',
            shirtColor: '#8b6b44', pantsColor: '#6f4f31', bootsColor: '#4d3522',
            equipment: { ...DEFAULT_CONFIG.equipment, hood: true, cape: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Deer",
        role: "Grazer",
        color: "bg-yellow-700",
        config: {
            ...CREATURE_MORPHS.grazer,
            impersonationModel: 'deer',
            bodyType: 'female', bodyVariant: 'slim', outfit: 'naked', skinColor: '#b88247',
            hairStyle: 'crew', hairColor: '#7b4f2a',
            shirtColor: '#8a5a2f', pantsColor: '#5c3a21', bootsColor: '#3f2918',
            equipment: { ...DEFAULT_CONFIG.equipment, hood: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Chicken",
        role: "Fowl",
        color: "bg-yellow-300",
        config: {
            ...CREATURE_MORPHS.fowl,
            impersonationModel: 'chicken',
            bodyType: 'female', bodyVariant: 'slim', outfit: 'naked', skinColor: '#f3e4bf',
            hairStyle: 'crew', hairColor: '#d97706',
            shirtColor: '#fff7e0', pantsColor: '#f1f5f9', bootsColor: '#b45309',
            equipment: { ...DEFAULT_CONFIG.equipment, hood: true, cape: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Pig",
        role: "Forager",
        color: "bg-rose-400",
        config: {
            ...CREATURE_MORPHS.forager,
            impersonationModel: 'pig',
            bodyType: 'male', bodyVariant: 'heavy', outfit: 'naked', skinColor: '#f2a3b3',
            hairStyle: 'bald',
            shirtColor: '#f7b2c1', pantsColor: '#e78fa5', bootsColor: '#9d174d',
            equipment: { ...DEFAULT_CONFIG.equipment, belt: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Sheep",
        role: "Wool",
        color: "bg-slate-200",
        config: {
            ...CREATURE_MORPHS.wool,
            impersonationModel: 'sheep',
            bodyType: 'female', bodyVariant: 'average', outfit: 'naked', skinColor: '#f8f5ef',
            hairStyle: 'crew', hairColor: '#ffffff',
            shirtColor: '#f1f5f9', pantsColor: '#e2e8f0', bootsColor: '#94a3b8',
            equipment: { ...DEFAULT_CONFIG.equipment, cape: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Lizard",
        role: "Reptile",
        color: "bg-green-700",
        config: {
            ...CREATURE_MORPHS.reptile,
            impersonationModel: 'lizard',
            bodyType: 'male', bodyVariant: 'slim', outfit: 'naked', skinColor: '#4d7c0f',
            hairStyle: 'bald',
            shirtColor: '#3f6212', pantsColor: '#365314', bootsColor: '#1f3b08',
            equipment: { ...DEFAULT_CONFIG.equipment, mask: true, hood: true },
            selectedItem: null, weaponStance: 'side'
        }
    },
    {
        name: "Horse",
        role: "Mount",
        color: "bg-amber-700",
        config: {
            ...CREATURE_MORPHS.mount,
            impersonationModel: 'horse',
            bodyType: 'male', bodyVariant: 'muscular', outfit: 'naked', skinColor: '#8b5e3c',
            hairStyle: 'crew', hairColor: '#2f1b12',
            shirtColor: '#6f4e37', pantsColor: '#5a3e2b', bootsColor: '#2f1b12',
            equipment: { ...DEFAULT_CONFIG.equipment, belt: true, cape: true },
            selectedItem: null, weaponStance: 'shoulder'
        }
    }
];

const IMPERSONATION_PRESETS: ImpersonatePreset[] = [...NPC_PRESETS, ...NON_HUMANOID_PRESETS];

const CITY_GUARD_STAGE_COLORS: Record<2 | 3, string> = {
    2: '#f1f5f9',
    3: '#d4af37'
};

const CITY_GUARD_PADDED_ARMOR_STAGE_COLORS: Record<2 | 3, string> = {
    2: '#4b3621',
    3: '#111111'
};

const CITY_GUARD_PANTS_STAGE_COLORS: Record<2 | 3, string> = {
    2: '#4b5563',
    3: '#111111'
};

type EquipmentDisplayInfo = {
    slot: keyof PlayerConfig['equipment'];
    label: string;
    note: string;
    primaryColor: string;
    accentColor?: string;
};

const getFirstDefinedColor = (...colors: Array<string | undefined>) => colors.find((color): color is string => !!color) ?? '#94a3b8';

const getEnabledEquipmentDetails = (preset: ImpersonatePreset): EquipmentDisplayInfo[] => {
    const config = preset.config;

    return Object.entries(config.equipment ?? {})
        .filter(([, enabled]) => !!enabled)
        .map(([slot]) => slot as keyof PlayerConfig['equipment'])
        .map((slot) => {
            switch (slot) {
                case 'helm':
                    return {
                        slot,
                        label: 'Helm',
                        note: 'Head armor / crest',
                        primaryColor: getFirstDefinedColor(config.embellishmentColor, config.paddedArmorColor, config.robeTrimColor, config.mageHatBandColor),
                        accentColor: getFirstDefinedColor(config.mageHatColor, config.hoodColor, config.hairColor)
                    };
                case 'shoulders':
                    return {
                        slot,
                        label: 'Shoulders',
                        note: 'Pauldrons / mantle',
                        primaryColor: getFirstDefinedColor(config.embellishmentColor, config.paddedArmorColor, config.robeTrimColor),
                        accentColor: getFirstDefinedColor(config.shirtColor, config.robeColor)
                    };
                case 'shield':
                    return {
                        slot,
                        label: 'Shield',
                        note: 'Defensive plate / emblem',
                        primaryColor: getFirstDefinedColor(config.embellishmentColor, config.paddedArmorColor, config.shirtColor),
                        accentColor: getFirstDefinedColor(config.robeTrimColor, config.shirtColor2, config.bootsColor)
                    };
                case 'shirt':
                case 'leatherDoublet':
                    return {
                        slot,
                        label: slot === 'shirt' ? 'Shirt' : 'Leather Doublet',
                        note: 'Base torso layer',
                        primaryColor: getFirstDefinedColor(config.shirtColor, config.robeColor, config.apronColor),
                        accentColor: getFirstDefinedColor(config.shirtColor2, config.robeTrimColor, config.apronDetailColor)
                    };
                case 'pants':
                case 'hideBreeches':
                case 'leatherPants':
                case 'chainLeggings':
                case 'plateLeggings':
                case 'warlordLegPlates':
                case 'greaves':
                case 'shorts':
                case 'skirt':
                    return {
                        slot,
                        label: slot
                            .replace(/([A-Z])/g, ' $1')
                            .replace(/^./, (char) => char.toUpperCase()),
                        note: 'Leg armor / lower-body layer',
                        primaryColor: getFirstDefinedColor(config.pantsColor, config.bootsColor, config.apronColor),
                        accentColor: getFirstDefinedColor(config.embellishmentColor, config.apronDetailColor)
                    };
                case 'quiltedArmor':
                case 'leatherArmor':
                case 'heavyLeatherArmor':
                case 'ringMail':
                case 'plateMail':
                    return {
                        slot,
                        label: slot
                            .replace(/([A-Z])/g, ' $1')
                            .replace(/^./, (char) => char.toUpperCase()),
                        note: 'Chest armor / padding',
                        primaryColor: getFirstDefinedColor(config.paddedArmorColor, config.embellishmentColor, config.shirtColor),
                        accentColor: getFirstDefinedColor(config.shirtColor, config.robeTrimColor)
                    };
                case 'robe':
                    return {
                        slot,
                        label: 'Robe',
                        note: 'Spellcaster outer layer',
                        primaryColor: getFirstDefinedColor(config.robeColor, config.shirtColor),
                        accentColor: getFirstDefinedColor(config.robeTrimColor, config.embellishmentColor)
                    };
                case 'mageHat':
                    return {
                        slot,
                        label: 'Mage Hat',
                        note: 'Wizard headwear',
                        primaryColor: getFirstDefinedColor(config.mageHatColor, config.hoodColor),
                        accentColor: getFirstDefinedColor(config.mageHatBandColor, config.robeTrimColor)
                    };
                case 'bracers':
                case 'gloves':
                    return {
                        slot,
                        label: slot === 'bracers' ? 'Bracers' : 'Gloves',
                        note: 'Arm accents / protection',
                        primaryColor: getFirstDefinedColor(config.embellishmentColor, config.paddedArmorColor, config.bootsColor),
                        accentColor: getFirstDefinedColor(config.shirtColor, config.robeTrimColor)
                    };
                case 'cape':
                    return {
                        slot,
                        label: 'Cape',
                        note: 'Back layer / faction cloth',
                        primaryColor: getFirstDefinedColor(config.robeColor, config.shirtColor, config.embellishmentColor),
                        accentColor: getFirstDefinedColor(config.robeTrimColor, config.shirtColor2)
                    };
                case 'belt':
                    return {
                        slot,
                        label: 'Belt',
                        note: 'Waist strap / utility band',
                        primaryColor: getFirstDefinedColor(config.pantsColor, config.bootsColor, config.apronDetailColor),
                        accentColor: getFirstDefinedColor(config.shirtColor, config.robeTrimColor)
                    };
                case 'blacksmithApron':
                    return {
                        slot,
                        label: 'Blacksmith Apron',
                        note: 'Forge apron with trim',
                        primaryColor: getFirstDefinedColor(config.apronColor, config.shirtColor, config.pantsColor),
                        accentColor: getFirstDefinedColor(config.apronDetailColor, config.embellishmentColor)
                    };
                case 'mask':
                    return {
                        slot,
                        label: 'Mask',
                        note: 'Face covering',
                        primaryColor: getFirstDefinedColor(config.hoodColor, config.pupilColor, config.lipColor),
                        accentColor: getFirstDefinedColor(config.scleraColor, config.skinColor)
                    };
                case 'hood':
                    return {
                        slot,
                        label: 'Hood',
                        note: 'Cloak hood / cowl',
                        primaryColor: getFirstDefinedColor(config.hoodColor, config.robeColor),
                        accentColor: getFirstDefinedColor(config.robeTrimColor, config.hairColor)
                    };
                case 'shoes':
                    return {
                        slot,
                        label: 'Shoes',
                        note: 'Boots / footwear',
                        primaryColor: getFirstDefinedColor(config.bootsColor, config.pantsColor),
                        accentColor: getFirstDefinedColor(config.pantsColor, config.embellishmentColor)
                    };
                case 'skullcap':
                    return {
                        slot,
                        label: 'Skullcap',
                        note: 'Fitted head covering',
                        primaryColor: getFirstDefinedColor(config.hairColor, config.hoodColor, config.embellishmentColor),
                        accentColor: getFirstDefinedColor(config.skinColor, config.shirtColor)
                    };
                default:
                    return {
                        slot,
                        label: String(slot)
                            .replace(/([A-Z])/g, ' $1')
                            .replace(/^./, (char) => char.toUpperCase()),
                        note: 'Enabled equipment',
                        primaryColor: getFirstDefinedColor(config.embellishmentColor, config.shirtColor, config.pantsColor),
                        accentColor: getFirstDefinedColor(config.robeTrimColor, config.bootsColor)
                    };
            }
        });
};

export const ImpersonateControls: React.FC<ImpersonateControlsProps> = ({ setConfig, onResetToBase }) => {
    const [presetStages, setPresetStages] = React.useState<Record<string, EmbellishmentStage>>({});
    const [infoPreset, setInfoPreset] = React.useState<ImpersonatePreset | null>(null);

    const isHumanoidPreset = (preset: ImpersonatePreset) => (preset.config.impersonationModel ?? 'humanoid') === 'humanoid';
    const getPresetStage = (preset: ImpersonatePreset): EmbellishmentStage => presetStages[preset.name] ?? 1;

    const getHumanoidStageConfig = (preset: ImpersonatePreset, stage: EmbellishmentStage): Partial<PlayerConfig> => {
        if (stage === 1) {
            return {
                embellishmentColor: undefined,
                paddedArmorColor: undefined
            };
        }

        const stageConfig: Partial<PlayerConfig> = {
            embellishmentColor: CITY_GUARD_STAGE_COLORS[stage],
            paddedArmorColor: CITY_GUARD_PADDED_ARMOR_STAGE_COLORS[stage]
        };

        if (preset.name === 'City Guard') {
            stageConfig.pantsColor = CITY_GUARD_PANTS_STAGE_COLORS[stage];
        }

        return stageConfig;
    };

    const applyPreset = (preset: ImpersonatePreset, stage: EmbellishmentStage = 1) => {
        const stageConfig = isHumanoidPreset(preset) ? getHumanoidStageConfig(preset, stage) : {};
        const unitColorOverrides: Partial<PlayerConfig> = preset.name === 'Ranger'
            ? { hoodColor: '#2e8b57', robeColor: '#2e8b57' }
            : preset.name === 'Assassin'
                ? { hoodColor: '#000000' }
                : {};

        setConfig(prev => ({
            ...prev,
            embellishmentColor: undefined,
            paddedArmorColor: undefined,
            hoodColor: DEFAULT_CONFIG.hoodColor,
            robeColor: DEFAULT_CONFIG.robeColor,
            ...preset.config,
            ...unitColorOverrides,
            ...stageConfig,
            impersonationModel: preset.config.impersonationModel ?? 'humanoid',
            // Ensure equipment object is merged correctly to reset unspecified slots
            equipment: {
                ...DEFAULT_CONFIG.equipment,
                ...preset.config.equipment
            }
        }));
    };
    
    const closeInfoModal = () => setInfoPreset(null);
    const activeInfoStage = infoPreset ? getPresetStage(infoPreset) : 1;
    const activeInfoEquipment = infoPreset ? getEnabledEquipmentDetails(infoPreset) : [];
    const activeInfoStats = infoPreset && isHumanoidPreset(infoPreset) && activeInfoStage === 1
        ? HUMANOID_PRESET_STATS[infoPreset.name] ?? null
        : null;
    const humanoidPresets = NPC_PRESETS;
    const nonHumanoidPresets = NON_HUMANOID_PRESETS;

    const renderPresetCard = (npc: ImpersonatePreset) => {
        const isHumanoid = isHumanoidPreset(npc);
        const presetStage = isHumanoid ? getPresetStage(npc) : 1;

        return (
            <div
                key={npc.name}
                className="relative group overflow-hidden rounded-2xl border border-slate-700/80 bg-gradient-to-b from-slate-800/95 to-slate-900/95 p-4 text-left transition-all duration-200 hover:-translate-y-0.5 hover:border-blue-400/50 hover:shadow-[0_12px_28px_-18px_rgba(59,130,246,0.85)]"
            >
                <button
                    type="button"
                    onClick={() => applyPreset(npc, presetStage)}
                    className="w-full pr-10 text-left active:scale-[0.99]"
                >
                    <div className={`pointer-events-none absolute -right-12 -top-12 h-28 w-28 rounded-full blur-2xl opacity-20 transition-opacity group-hover:opacity-35 ${npc.color}`} />

                    <div className="relative z-10 flex items-start justify-between gap-2">
                        <span className={`inline-flex rounded-md px-2.5 py-1 text-[9px] font-black uppercase tracking-[0.18em] text-white/95 ${npc.color}`}>
                            {npc.role}
                        </span>
                    </div>

                    <h4 className="relative z-10 mt-3 text-base font-black uppercase tracking-tight text-white leading-tight break-words">
                        {npc.name}
                    </h4>

                    <div className="relative z-10 mt-4 flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase tracking-[0.16em] text-slate-400 group-hover:text-slate-200 transition-colors">
                            {isHumanoid ? `Apply stage ${presetStage}` : 'Apply look'}
                        </span>
                        <span className="h-px w-8 bg-slate-600 transition-colors group-hover:bg-blue-300/80" />
                    </div>
                </button>

                <button
                    type="button"
                    onClick={() => setInfoPreset(npc)}
                    className="absolute right-3 top-3 z-20 inline-flex h-7 items-center justify-center rounded-full border border-white/20 bg-slate-900/85 px-2.5 text-[9px] font-black uppercase tracking-[0.14em] text-slate-200 transition-colors hover:border-blue-300/60 hover:text-blue-100"
                >
                    Info
                </button>

                {isHumanoid && (
                    <div className="relative z-10 mt-3 flex items-center justify-start gap-1.5">
                        {[1, 2, 3].map((stage) => {
                            const stageValue = stage as EmbellishmentStage;
                            const isActive = presetStage === stageValue;

                            return (
                                <button
                                    type="button"
                                    key={`${npc.name}-stage-${stage}`}
                                    onClick={() => {
                                        setPresetStages(prev => ({
                                            ...prev,
                                            [npc.name]: stageValue
                                        }));
                                        applyPreset(npc, stageValue);
                                    }}
                                    className={`rounded-md border px-2 py-1 text-[10px] font-black uppercase tracking-[0.12em] transition-colors ${
                                        isActive
                                            ? 'border-blue-300/70 bg-blue-500/25 text-blue-100'
                                            : 'border-slate-600/80 bg-slate-800/70 text-slate-300 hover:border-slate-400 hover:text-white'
                                    }`}
                                >
                                    S{stage}
                                </button>
                            );
                        })}
                    </div>
                )}
            </div>
        );
    };

    return (
        <div className="h-full overflow-y-auto custom-scrollbar pr-1">
            <div className="mb-5 rounded-2xl border border-blue-500/30 bg-gradient-to-br from-blue-500/15 via-blue-500/5 to-slate-900/40 p-4">
                <div className="flex items-center justify-between gap-3">
                    <div>
                        <h3 className="text-blue-100 font-black text-sm uppercase tracking-[0.14em]">Identity Presets</h3>
                        <p className="mt-1 text-[11px] text-blue-200/70">Apply a full look profile in one click.</p>
                    </div>
                    <div className="flex items-center gap-2">
                        <button
                            type="button"
                            onClick={onResetToBase}
                            className="rounded-full border border-white/25 bg-slate-900/75 px-3 py-1 text-[10px] font-black uppercase tracking-widest text-slate-100 transition-colors hover:border-blue-300/60 hover:text-blue-100"
                        >
                            Base
                        </button>
                        <span className="rounded-full border border-blue-300/40 bg-blue-500/10 px-2.5 py-1 text-[10px] font-black uppercase tracking-widest text-blue-200">
                            {IMPERSONATION_PRESETS.length} profiles
                        </span>
                    </div>
                </div>
            </div>

            <div className="mb-3 mt-1 flex items-center justify-between">
                <h4 className="text-[11px] font-black uppercase tracking-[0.16em] text-blue-200/80">Humanoid</h4>
                <span className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">{humanoidPresets.length}</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {humanoidPresets.map(renderPresetCard)}
            </div>

            <div className="mb-3 mt-6 flex items-center justify-between">
                <h4 className="text-[11px] font-black uppercase tracking-[0.16em] text-blue-200/80">Non-Humanoid</h4>
                <span className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">{nonHumanoidPresets.length}</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {nonHumanoidPresets.map(renderPresetCard)}
            </div>

            {infoPreset && (
                <div
                    className="fixed inset-0 z-[120] flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm"
                    onClick={closeInfoModal}
                >
                    <div
                        className="w-full max-w-md rounded-2xl border border-blue-300/30 bg-gradient-to-b from-slate-800 to-slate-900 p-5 shadow-2xl"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="flex items-start justify-between gap-3">
                            <div>
                                <h4 className="text-lg font-black uppercase tracking-[0.06em] text-white">{infoPreset.name}</h4>
                                <p className="mt-1 text-[11px] font-bold uppercase tracking-[0.14em] text-blue-200/80">{infoPreset.role}</p>
                            </div>
                            <button
                                type="button"
                                onClick={closeInfoModal}
                                className="rounded-full border border-white/20 px-3 py-1 text-[10px] font-black uppercase tracking-[0.12em] text-slate-200 transition-colors hover:border-blue-300/60 hover:text-blue-100"
                            >
                                Close
                            </button>
                        </div>

                        <div className="mt-4 grid grid-cols-2 gap-2 text-[11px] text-slate-200">
                            <div className="rounded-lg border border-white/10 bg-slate-900/70 px-3 py-2"><span className="text-slate-400">Model:</span> {(infoPreset.config.impersonationModel ?? 'humanoid').toUpperCase()}</div>
                            <div className="rounded-lg border border-white/10 bg-slate-900/70 px-3 py-2"><span className="text-slate-400">Body:</span> {infoPreset.config.bodyType ?? '-'}</div>
                            <div className="rounded-lg border border-white/10 bg-slate-900/70 px-3 py-2"><span className="text-slate-400">Variant:</span> {infoPreset.config.bodyVariant ?? '-'}</div>
                            <div className="rounded-lg border border-white/10 bg-slate-900/70 px-3 py-2">
                                <span className="text-slate-400">{isHumanoidPreset(infoPreset) ? 'Outfit' : 'Skin'}:</span>{' '}
                                {isHumanoidPreset(infoPreset) ? infoPreset.name : (infoPreset.config.skinColor ?? '-')}
                            </div>
                            <div className="rounded-lg border border-white/10 bg-slate-900/70 px-3 py-2"><span className="text-slate-400">Weapon:</span> {infoPreset.config.selectedItem ?? 'None'}</div>
                            <div className="rounded-lg border border-white/10 bg-slate-900/70 px-3 py-2"><span className="text-slate-400">Stage:</span> {isHumanoidPreset(infoPreset) ? `S${activeInfoStage}` : 'N/A'}</div>
                            <div className="rounded-lg border border-white/10 bg-slate-900/70 px-3 py-2"><span className="text-slate-400">HP:</span> {activeInfoStats?.health ?? '-'}</div>
                            <div className="rounded-lg border border-white/10 bg-slate-900/70 px-3 py-2"><span className="text-slate-400">Chakra:</span> {activeInfoStats?.chakra ?? '-'}</div>
                            <div className="rounded-lg border border-white/10 bg-slate-900/70 px-3 py-2"><span className="text-slate-400">Attack:</span> {activeInfoStats?.attack ?? '-'}</div>
                            <div className="rounded-lg border border-white/10 bg-slate-900/70 px-3 py-2"><span className="text-slate-400">Defense:</span> {activeInfoStats?.defense ?? '-'}</div>
                            <div className="rounded-lg border border-white/10 bg-slate-900/70 px-3 py-2"><span className="text-slate-400">Evasion:</span> {activeInfoStats?.evasion ?? '-'}</div>
                            <div className="rounded-lg border border-white/10 bg-slate-900/70 px-3 py-2"><span className="text-slate-400">Dexterity:</span> {activeInfoStats?.dexterity ?? '-'}</div>
                        </div>

                        <div className="mt-3 rounded-lg border border-white/10 bg-slate-900/70 p-3">
                            <div className="flex items-center justify-between gap-2">
                                <p className="text-[10px] font-black uppercase tracking-[0.14em] text-slate-400">Enabled Equipment</p>
                                <span className="text-[10px] font-black uppercase tracking-[0.14em] text-slate-500">
                                    {activeInfoEquipment.length} active
                                </span>
                            </div>

                            {activeInfoEquipment.length > 0 ? (
                                <div className="mt-2 space-y-2">
                                    {activeInfoEquipment.map((item) => (
                                        <div
                                            key={item.slot}
                                            className="flex items-start justify-between gap-3 rounded-md border border-white/10 bg-slate-950/45 px-2.5 py-2"
                                        >
                                            <div className="flex min-w-0 items-start gap-2">
                                                <div className="mt-0.5 flex items-center gap-1.5">
                                                    <span
                                                        className="h-3.5 w-3.5 rounded-full border border-white/20 shadow-inner"
                                                        style={{ backgroundColor: item.primaryColor }}
                                                    />
                                                    {item.accentColor && (
                                                        <span
                                                            className="h-3.5 w-3.5 rounded-full border border-white/20 shadow-inner"
                                                            style={{ backgroundColor: item.accentColor }}
                                                        />
                                                    )}
                                                </div>

                                                <div className="min-w-0">
                                                    <p className="truncate text-[11px] font-black uppercase tracking-[0.12em] text-slate-100">
                                                        {item.label}
                                                    </p>
                                                    <p className="text-[10px] text-slate-400">
                                                        {item.note}
                                                    </p>
                                                </div>
                                            </div>

                                            <div className="shrink-0 text-right">
                                                <p className="text-[10px] font-black uppercase tracking-[0.12em] text-slate-200">
                                                    {item.primaryColor}
                                                </p>
                                                {item.accentColor && (
                                                    <p className="text-[10px] text-slate-500">
                                                        Accent {item.accentColor}
                                                    </p>
                                                )}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <p className="mt-1 text-[11px] text-slate-100">None</p>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
