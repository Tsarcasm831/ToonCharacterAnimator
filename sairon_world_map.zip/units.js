import { W, H, unitLayer } from './constants.js';
import { mk } from './utils.js';
import { MODEL, state } from './model.js';
import { select, startDragWhole } from './interactions.js';
import { registerRenderer } from './render.js';
import { getClockTime } from './ui/sairon-clock.js';

const BASE_SPEED = 0.012; 

// Default definitions including type
const DEFAULT_UNITS = [
  {
    "id": "u1",
    "type": "caravan",
    "name": "Tea Route Caravan",
    "path": [
      [42.3867, 29.6296], [41.5, 24.5], [43.6297, 17.9739], [43.9577, 12.9591], [48.6436, 7.9034]
    ],
    "currentSegment": 0, "t": 0, "direction": 1, "state": "idle"
  },
  {
    "id": "u2",
    "type": "combat",
    "name": "Border Patrol",
    "path": [
      [42.3867, 29.6296], [35.635, 30.069], [32.885, 35.802], [27.885, 35.838]
    ],
    "currentSegment": 0, "t": 0, "direction": 1, "state": "active"
  },
  {
    "id": "u3",
    "type": "aid",
    "name": "Medical Relief",
    "path": [
      [27.885, 11.437], [28.148, 18.301], [33.639, 21.168], [35.444, 26.902], [42.386, 29.629]
    ],
    "currentSegment": 0, "t": 0, "direction": 1, "state": "active"
  }
];

let pathsGroup, markersGroup;
// Cache DOM elements to prevent thrashing
const markersMap = new Map();

export function initUnits() {
    if (!MODEL.units) MODEL.units = [];
    
    // Seed missing defaults or update types if missing
    const existingIds = new Set(MODEL.units.map(u => u.id));
    DEFAULT_UNITS.forEach(def => {
        if (!existingIds.has(def.id)) {
            MODEL.units.push(JSON.parse(JSON.stringify(def)));
        } else {
            // Ensure type exists on legacy data
            const u = MODEL.units.find(x => x.id === def.id);
            if(u && !u.type) u.type = def.type;
        }
    });

    // Ensure strictly unique IDs for caching
    MODEL.units.forEach((u, i) => {
        if (!u.id) u.id = `unit_${Date.now()}_${i}`;
    });

    if (!pathsGroup) {
        pathsGroup = mk('g', {class: 'unit-paths'});
        markersGroup = mk('g', {class: 'unit-markers'});
        unitLayer.appendChild(pathsGroup);
        unitLayer.appendChild(markersGroup);
    }

    registerRenderer('units', drawUnitPaths);
    drawUnitPaths();
    requestAnimationFrame(animateUnits);
}

function animateUnits() {
    const clock = getClockTime();
    updateUnits(clock);
    // updateUnitMarkers();
    requestAnimationFrame(animateUnits);
}

function updateUnits(clock) {
    (MODEL.units || []).forEach(u => {
        if (!u.path || u.path.length < 2) return;

        // Delegate logic based on type
        if (u.type === 'caravan') updateCaravan(u, clock);
        else if (u.type === 'combat') updateCombat(u, clock);
        else if (u.type === 'aid') updateAid(u, clock);
        else updateGeneric(u); // Fallback
    });
}

// Caravan Logic: Weekly schedule, variable speed
function updateCaravan(u, clock) {
    // Schedule: Depart Monday morning (Hour 6)
    if (u.state === 'idle' || !u.state) {
        // Only start if at beginning
        if (u.t <= 0 && u.currentSegment === 0) {
            // Check schedule: Monday (0) between 6am and 9am
            if (clock.parts.weekdayIndex === 0 && clock.hour >= 6 && clock.hour < 9) {
                u.state = 'active';
                u.direction = 1;
            }
        }
    }

    if (u.state === 'active') {
        // Laden (dir=1) is slow. Empty (dir=-1) is fast.
        const speed = (u.direction > 0) ? (BASE_SPEED / 30) : (BASE_SPEED / 10);
        moveUnit(u, speed);

        // Turn around logic handled in moveUnit, but we might want pauses
        if (u.t >= 1 && u.currentSegment >= u.path.length - 2) {
            // Arrived at destination. Turn around immediately
            u.direction = -1;
        } else if (u.t <= 0 && u.currentSegment <= 0) {
            // Arrived back home.
            u.state = 'idle';
            u.direction = 1; // Ready for next load
        }
    }
}

// Combat Logic: Patrols
function updateCombat(u, clock) {
    const isNight = clock.period === 'night';
    // Slower at night
    if (isNight) {
        moveUnit(u, BASE_SPEED / 16); 
    } else {
        moveUnit(u, BASE_SPEED / 8);
    }
}

// Aid Logic: Fast response
function updateAid(u, clock) {
    // Adjusted to be reasonable (faster than caravan, but not teleporting)
    moveUnit(u, BASE_SPEED / 5);
}

// Generic/Fallback Logic
function updateGeneric(u) {
    moveUnit(u, BASE_SPEED / 10);
}

function moveUnit(u, speed) {
    if (!u.path || u.path.length < 2) return;
    
    // Ensure bounds
    if (u.currentSegment >= u.path.length - 1) {
        u.currentSegment = u.path.length - 2;
        u.t = 1;
    }
    if (u.currentSegment < 0) {
        u.currentSegment = 0;
        u.t = 0;
    }

    const p1 = u.path[u.currentSegment];
    const p2 = u.path[u.currentSegment + 1];
    
    const dx = p2[0] - p1[0];
    const dy = p2[1] - p1[1];
    const dist = Math.sqrt(dx*dx + dy*dy);
    
    const dt = dist > 0.001 ? (speed / dist) : 0;
    
    u.t += dt * u.direction;
    
    if (u.t >= 1) {
        if (u.currentSegment < u.path.length - 2) {
            u.t -= 1;
            u.currentSegment++;
        } else {
            u.t = 1;
            if (u.direction === 1) u.direction = -1;
        }
    } else if (u.t <= 0) {
        if (u.currentSegment > 0) {
            u.t += 1;
            u.currentSegment--;
        } else {
            u.t = 0;
            if (u.direction === -1) u.direction = 1;
        }
    }
}

export function drawUnitPaths() {
    if (!pathsGroup) return;
    while(pathsGroup.firstChild) pathsGroup.removeChild(pathsGroup.firstChild);
    
    (MODEL.units || []).forEach((u, i) => {
        if (!u.path || u.path.length < 2) return;

        const isSel = state.selected && state.selected.kind === 'unit' && state.selected.key === i;
        const points = u.path.map(p => `${p[0] * W / 100},${p[1] * H / 100}`).join(' ');
        
        // Invisible hit path
        const hitPath = mk('polyline', {
            points: points,
            fill: 'none',
            stroke: 'transparent',
            'stroke-width': '16',
            style: 'cursor: pointer; pointer-events: stroke;'
        });
        
        hitPath.addEventListener('mousedown', (e) => {
            if (state.mode === 'select' || state.mode === 'move') {
                e.stopPropagation();
                select('unit', i);
                if (state.mode === 'move') startDragWhole(e, 'unit', i);
            }
        });

        // Visible path trace
        let strokeColor = 'rgba(255,255,255,0.4)';
        if (u.type === 'combat') strokeColor = 'rgba(239, 68, 68, 0.5)'; // red tint
        else if (u.type === 'aid') strokeColor = 'rgba(34, 197, 94, 0.5)'; // green tint
        else if (u.type === 'caravan') strokeColor = 'rgba(234, 179, 8, 0.5)'; // yellow tint

        if (isSel) strokeColor = 'rgba(255, 200, 0, 0.9)';

        const visPath = mk('polyline', {
            points: points,
            fill: 'none',
            stroke: strokeColor,
            'stroke-width': isSel ? '3' : '1.5',
            'stroke-dasharray': isSel ? 'none' : '4,4',
            style: 'pointer-events: none;'
        });

        pathsGroup.appendChild(hitPath);
        pathsGroup.appendChild(visPath);
    });
}

function updateUnitMarkers() {
    if (!markersGroup) return;
    
    const activeIds = new Set();
    
    (MODEL.units || []).forEach((u, i) => {
        if (!u.path || u.path.length < 2) return;
        activeIds.add(u.id);

        let marker = markersMap.get(u.id);
        
        // Setup icon name
        let iconName = 'caravan.png';
        if (u.type === 'caravan') {
             iconName = u.direction > 0 ? 'caravan_laden.png' : 'caravan_empty.png';
        } else if (u.type === 'combat') {
             iconName = 'combat_unit.png';
        } else if (u.type === 'aid') {
             iconName = 'aid_unit.png';
        }

        // Create DOM if needed
        if (!marker) {
            marker = createUnitMarker(u, iconName);
            markersMap.set(u.id, marker);
            markersGroup.appendChild(marker);
        }

        // Update Position & Rotation
        const p1 = u.path[u.currentSegment];
        const p2 = u.path[u.currentSegment + 1];
        
        const x = p1[0] + (p2[0] - p1[0]) * u.t;
        const y = p1[1] + (p2[1] - p1[1]) * u.t;
        
        const dirX = (p2[0] - p1[0]) * u.direction;
        const dirY = (p2[1] - p1[1]) * u.direction;
        const angle = Math.atan2(dirY, dirX) * 180 / Math.PI + 180;

        marker.setAttribute('transform', `translate(${x * W / 100}, ${y * H / 100}) rotate(${angle})`);
        
        // Update Icon (only if changed)
        const img = marker.firstChild;
        const targetHref = `assets/units/icons/${iconName}`;
        if (img.getAttribute('href') !== targetHref) {
            img.setAttribute('href', targetHref);
        }

        // Update Selection Highlight
        const isSel = state.selected && state.selected.kind === 'unit' && state.selected.key === i;
        const targetFilter = isSel ? "drop-shadow(0 0 3px #fbbf24)" : "drop-shadow(1px 1px 2px rgba(0,0,0,0.6))";
        if (img.style.filter !== targetFilter) {
            img.style.filter = targetFilter;
        }
        
        // Update pointer to index for interactions
        marker.dataset.index = i; 
    });
    
    // Garbage collect markers
    for (const [id, el] of markersMap.entries()) {
        if (!activeIds.has(id)) {
            el.remove();
            markersMap.delete(id);
        }
    }
}

function createUnitMarker(u, iconName) {
    const g = mk('g', { class: 'unit-marker', 'data-id': u.id });
    const size = 28;
    const img = mk('image', {
        href: `assets/units/icons/${iconName}`,
        x: -size/2, y: -size/2,
        width: size, height: size,
        style: 'cursor: pointer;'
    });
    g.appendChild(img);
    
    g.addEventListener('mousedown', (e) => {
        if (state.mode === 'select' || state.mode === 'move') {
            e.stopPropagation();
            // Use fresh index from dataset or find it
            const idx = parseInt(g.dataset.index, 10);
            if (!isNaN(idx)) {
                select('unit', idx);
                if (state.mode === 'move') startDragWhole(e, 'unit', idx);
            }
        }
    });
    return g;
}
