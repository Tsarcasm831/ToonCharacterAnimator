export const W = 1018, H = 968; // viewBox

export const svg = document.getElementById('map');
export const dLayer = document.getElementById('landLayer');
export const landBaseLayer = document.getElementById('landBaseLayer');
export const rLayer = document.getElementById('roadLayer');
export const riverLayer = document.getElementById('riverLayer');
export const pLayer = document.getElementById('poiLayer');
export const unitLayer = document.getElementById('unitLayer');
export const hLayer = document.getElementById('handleLayer');
export const tip = document.getElementById('tip');
export const out = document.getElementById('json');
export const oceanMaskShapes = document.getElementById('oceanMaskShapes');

export const $ = sel => document.querySelector(sel);

/* add paint layers */
export const forestLayer = document.getElementById('forestLayer');
export const mountainLayer = document.getElementById('mountainLayer');

export const LAND_ICONS = {
  'Land01': 'assets/images/lands/leaf.png',          // Land of Fire
  'Land15': 'assets/images/lands/sand.png',          // Land of Wind
  'Land12': 'assets/images/lands/stone.png',         // Land of Earth
  'Land22': 'assets/images/lands/mist.png',          // Land of Water
  'Land13': 'assets/images/lands/cloud.png',         // Land of Lightning
  'Land08': 'assets/images/lands/sound.png',         // Land of Sound
  'Land17': 'assets/images/lands/grass.png',         // Land of Grass
  'Land09': 'assets/images/lands/waterfall.png',     // Land of Waterfalls
  'Land23': 'assets/images/lands/yurei.png',         // Land of Ghosts
  'Land16': 'assets/images/lands/rain.png'           // Land of Rain
};