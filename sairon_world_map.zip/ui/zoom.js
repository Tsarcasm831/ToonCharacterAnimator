import { W, H, svg } from '../constants.js';

let zoomThrottle = null;

export function initZoom() {
  svg.addEventListener('wheel', throttledWheelZoom, { passive: false });
}

export function resetViewBox() {
  setViewBox({ x: 0, y: 0, w: W, h: H });
}

export function startPan(e, onClick) {
  const startX = e.clientX;
  const startY = e.clientY;
  const vb = parseViewBox();
  const startViewBox = { ...vb };
  let moved = false;

  const onMove = (ev) => {
    if (Math.abs(ev.clientX - startX) > 3 || Math.abs(ev.clientY - startY) > 3) {
      moved = true;
    }

    if (moved) {
      const ctm = svg.getScreenCTM();
      if (ctm) {
        const dx = (ev.clientX - startX) / ctm.a;
        const dy = (ev.clientY - startY) / ctm.d;
        
        let nx = startViewBox.x - dx;
        let ny = startViewBox.y - dy;

        // Clamp to bounds (consistent with wheel zoom behavior)
        nx = Math.max(0, Math.min(W - startViewBox.w, nx));
        ny = Math.max(0, Math.min(H - startViewBox.h, ny));

        setViewBox({
          x: nx,
          y: ny,
          w: startViewBox.w,
          h: startViewBox.h
        });
      }
    }
  };

  const onUp = () => {
    window.removeEventListener('mousemove', onMove);
    window.removeEventListener('mouseup', onUp);
    if (!moved && onClick) {
      onClick();
    }
  };

  window.addEventListener('mousemove', onMove);
  window.addEventListener('mouseup', onUp);
}

function throttledWheelZoom(e) {
  e.preventDefault();
  if (zoomThrottle) return;
  zoomThrottle = requestAnimationFrame(() => {
    zoomThrottle = null;
    onWheelZoom(e);
  });
}

function parseViewBox() {
  const vb = (svg.getAttribute('viewBox') || '').trim().split(/\s+/).map(Number);
  return (vb.length === 4 && vb.every(n => !Number.isNaN(n))) ? { x: vb[0], y: vb[1], w: vb[2], h: vb[3] } : { x: 0, y: 0, w: W, h: H };
}

function setViewBox(vb) {
  svg.setAttribute('viewBox', `${vb.x} ${vb.y} ${vb.w} ${vb.h}`);
}

function onWheelZoom(e) {
  const vb = parseViewBox();
  const pt = svg.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY;
  const p = pt.matrixTransform(svg.getScreenCTM().inverse());
  const minW = W / 6, minH = H / 6, maxW = W, maxH = H;
  const zoomFactor = e.deltaY < 0 ? 0.9 : 1.1;
  const newW = Math.min(maxW, Math.max(minW, vb.w * zoomFactor));
  const newH = Math.min(maxH, Math.max(minH, vb.h * zoomFactor));
  const tx = (p.x - vb.x) / vb.w;
  const ty = (p.y - vb.y) / vb.h;
  let nx = p.x - tx * newW;
  let ny = p.y - ty * newH;
  nx = Math.max(0, Math.min(W - newW, nx));
  ny = Math.max(0, Math.min(H - newH, ny));
  setViewBox({ x: nx, y: ny, w: newW, h: newH });
}
