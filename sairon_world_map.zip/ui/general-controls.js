import { MODEL, state } from '../model.js';
import { drawAll } from '../render.js';
import { dumpJSON, exportUnityData } from '../export-utils.js';
import { autosave, preloadAssets } from '../utils.js';
import { select } from '../interactions.js';
import { LAND_ICONS } from '../constants.js';
import { POI_PAGE_MAP } from '../poi-pages/poi-page-map.js';

export function initStartScreen() {
  const screen = document.getElementById('startScreen');
  const loader = document.getElementById('loadingScreen');
  const btn = document.getElementById('startBtn');
  const sealsBtn = document.getElementById('sealsBtn');
  const unityBtn = document.getElementById('exportUnityBtn');
  
  if (sealsBtn) {
    sealsBtn.addEventListener('click', () => {
      window.location.href = 'shinobi_seals/index.html';
    });
  }

  if (unityBtn) {
    unityBtn.addEventListener('click', () => {
      exportUnityData();
    });
  }
  
  initSnowEffect();

  const playBtn = document.getElementById('playBtn');

  if (!screen) return;

  const startApp = async (isEditor) => {
    if (isEditor) {
      document.body.classList.add('editor-mode');
      document.body.classList.add('editor-open');
      const side = document.getElementById('side');
      if (side) side.classList.add('open');
    } else {
      document.body.classList.add('play-mode');
    }

    // Show loader
    screen.classList.add('hidden');
    if (loader) loader.hidden = false;
    
    // Preload
    const assets = collectAssets();
    const bar = document.getElementById('loadBar');
    const txt = document.getElementById('loadText');
    
    await preloadAssets(assets, (progress) => {
      const pct = Math.floor(progress * 100) + '%';
      if (bar) bar.style.width = pct;
      if (txt) txt.textContent = pct;
    });
    
    // Hide loader
    if (loader) {
      loader.classList.add('fade-out');
      setTimeout(() => { loader.hidden = true; }, 500);
    }
  };

  if (btn) btn.addEventListener('click', () => startApp(true));
  if (playBtn) playBtn.addEventListener('click', () => startApp(false));
}

function initSnowEffect() {
  const canvas = document.getElementById('snowCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  
  let w, h;
  const flakes = [];
  const count = 150;

  const resize = () => {
    w = canvas.width = window.innerWidth;
    h = canvas.height = window.innerHeight;
  };
  window.addEventListener('resize', resize);
  resize();

  for(let i=0; i<count; i++) {
    flakes.push({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * 2 + 1,
      s: Math.random() * 1 + 0.5,
      drift: Math.random() * 1 - 0.5
    });
  }

  function draw() {
    const screen = document.getElementById('startScreen');
    if (!screen || screen.classList.contains('hidden')) return;

    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "rgba(255, 255, 255, 0.8)";
    ctx.beginPath();

    for(let i=0; i<count; i++) {
      const f = flakes[i];
      ctx.moveTo(f.x, f.y);
      ctx.arc(f.x, f.y, f.r, 0, Math.PI*2, true);
    }
    ctx.fill();
    update();
    requestAnimationFrame(draw);
  }

  let angle = 0;
  function update() {
    angle += 0.01;
    for(let i=0; i<count; i++) {
      const f = flakes[i];
      f.y += f.s;
      f.x += Math.sin(angle) * 0.5 + f.drift;

      if(f.x > w + 5 || f.x < -5 || f.y > h) {
        if(i%3 > 0) { 
            flakes[i] = { x: Math.random() * w, y: -10, r: f.r, s: f.s, drift: f.drift };
        } else {
            if(Math.sin(angle) > 0) flakes[i] = { x: -5, y: Math.random() * h, r: f.r, s: f.s, drift: f.drift };
            else flakes[i] = { x: w+5, y: Math.random() * h, r: f.r, s: f.s, drift: f.drift };
        }
      }
    }
  }
  
  draw();
}

function collectAssets() {
  const assets = new Set(['Map of Naruto2.jpg']);
  
  // UI Icons
  ['A','B','C','D','E'].forEach(c => assets.add(`assets/icons/${c}.png`));
  for(let i=1; i<=12; i++) assets.add(`assets/icons/${i}.png`);
  
  // Land Icons
  Object.values(LAND_ICONS).forEach(u => assets.add(u));
  
  // Loading BG
  assets.add('assets/images/loading_ice.png');

  // Textures
  ['water_texture', 'sand', 'rock', 'ground', 'trees', 'grass', 'snow', 'plateauswithclouds', 'bamboojungle', 'tealeaves', 'islandjungle', 'steam', 'flowers'].forEach(t => {
    assets.add(`assets/textures/${t}.png`);
  });
  
  // Unit Icons
  ['caravan', 'caravan_laden', 'caravan_empty', 'aid_unit', 'combat_unit'].forEach(t => {
      assets.add(`assets/units/icons/${t}.png`);
  });

  // Land Pages & Scripts
  assets.add('land-pages/land.js');
  assets.add('land-pages/land.html');
  for(let i=1; i<=26; i++) assets.add(`land-pages/Land${String(i).padStart(2,'0')}.html`);
  for(let i=1; i<=11; i++) assets.add(`land-pages/Island${String(i).padStart(2,'0')}.html`);

  // Model Data (POI images & pages)
  (MODEL.poi || []).forEach(p => {
    if (p.image) assets.add(p.image);
    const page = POI_PAGE_MAP[p.id] || POI_PAGE_MAP[p.name];
    if (page) assets.add(page);
  });

  // Model Data (Land images)
  Object.values(MODEL.lands || {}).forEach(land => {
    land.ninjaRisks?.forEach(n => n.image && assets.add(n.image));
  });

  return Array.from(assets);
}

export function initEditorToggle() {
  const btn = document.getElementById('toggleEditorBtn');
  const side = document.getElementById('side');
  if (!btn || !side) return;

  const syncState = () => {
    const isMobile = window.innerWidth <= 980;
    const isOpen = isMobile ? side.classList.contains('open') : document.body.classList.contains('editor-open');
    btn.textContent = isOpen ? 'Close Editor' : 'Open Editor';
    window.dispatchEvent(new CustomEvent('editor:state', { detail: { isOpen } }));
  };

  const toggle = () => {
    const isMobile = window.innerWidth <= 980;
    if (isMobile) {
      side.classList.toggle('open');
    } else {
      document.body.classList.toggle('editor-open');
      window.dispatchEvent(new Event('resize')); 
    }
    // syncState handled by observer
  };

  btn.addEventListener('click', toggle);
  
  // Watch for external state changes (mobile menu, canvas click, etc)
  const observer = new MutationObserver(syncState);
  observer.observe(side, { attributes: true, attributeFilter: ['class'] });
  observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });
}

export function initModeAndVisibilityControls(onModeChange) {
  document.querySelectorAll('input[name="mode"]').forEach(r => r.addEventListener('change', e => {
    state.mode = e.target.value;
    state.drawing = null;
    document.body.dataset.mode = state.mode;
    drawAll();
    onModeChange?.();
  }));
  document.getElementById('edit').addEventListener('change', e => { state.edit = e.target.checked; drawAll(); });
  const dm = document.getElementById('darkMode');
  if (dm) {
    dm.addEventListener('change', e => {
      if (e.target.checked) document.body.classList.add('dark');
      else document.body.classList.remove('dark');
    });
  }
  document.getElementById('hideBackground')?.addEventListener('change', e => {
    const bgImg = document.getElementById('backgroundImage');
    if (bgImg) bgImg.style.display = e.target.checked ? 'none' : '';
    drawAll();
  });

  document.getElementById('toggleOcean')?.addEventListener('change', e => {
    const water = document.getElementById('waterLayer');
    if (water) water.style.display = e.target.checked ? '' : 'none';
  });

  const onToggle = id => { const el = document.getElementById(id); if (el) el.addEventListener('change', drawAll); };
  ['toggleLands', 'toggleRoads', 'toggleWalls', 'togglePOI', 'toggleRivers', 'toggleGrass', 'toggleForest', 'toggleMountains', 'toggleTextures'].forEach(onToggle);
}

export function initMobileMenuToggle() {
  const menuBtn = document.getElementById('mobileMenuBtn');
  if (!menuBtn) return;
  menuBtn.addEventListener('click', () => {
    document.getElementById('side').classList.toggle('open');
  });
}

export function initLandColorControl() {
  const sColor = document.getElementById('sColor');
  if (!sColor) return;
  sColor.addEventListener('input', e => {
    if (state.selected && state.selected.kind === 'land') {
      const land = MODEL.lands[state.selected.key];
      if (land) {
        land.color = e.target.value;
        drawAll();
      }
    }
  });
  sColor.addEventListener('change', () => {
    dumpJSON(); autosave(MODEL);
  });
}

export function initLegendControl() {
  const btn = document.getElementById('legendBtn');
  const modal = document.getElementById('landListModal');
  const close = document.getElementById('llClose');
  const list = document.getElementById('landList');

  if (!btn || !modal || !list) return;

  const populate = () => {
    list.innerHTML = '';
    const lands = Object.values(MODEL.lands).sort((a, b) => {
        const getNum = id => {
            const match = id.match(/Land(\d+)/);
            return match ? parseInt(match[1]) : 9999;
        };
        const na = getNum(a.id);
        const nb = getNum(b.id);
        if (na !== nb) return na - nb;
        return a.id.localeCompare(b.id);
    });
    
    lands.forEach(land => {
      const li = document.createElement('li');
      
      if (land.id.includes('_Island')) {
         li.style.paddingLeft = '36px';
         li.innerHTML = `<b style="border:none; background:transparent; color: var(--ink); min-width:20px">•</b> <span>${land.name || land.id}</span>`;
      } else {
         const num = land.id.replace(/\D/g, '');
         li.innerHTML = `<b>${num}</b> <span>${land.name || land.id}</span>`;
      }

      li.addEventListener('click', () => {
         select('land', land.id);
         modal.hidden = true;
      });
      list.appendChild(li);
    });
  };

  btn.addEventListener('click', () => {
    populate();
    modal.hidden = false;
  });

  close?.addEventListener('click', () => {
    modal.hidden = true;
  });
}
