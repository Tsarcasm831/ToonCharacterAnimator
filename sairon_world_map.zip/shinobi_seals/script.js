import { signs, jutsus } from './data.js';

// State
let currentMode = 'learn'; // 'learn' or 'practice'
let currentJutsu = jutsus[0];
let currentSequence = []; // The user's input so far
let isComplete = false;

// Elements
const displayArea = document.getElementById('display-area');
const grid = document.getElementById('hand-seal-grid');
const btnLearn = document.getElementById('btn-learn');
const btnPractice = document.getElementById('btn-practice');
const canvas = document.getElementById('bg-canvas');
const ctx = canvas.getContext('2d');

// Web Audio API
const AudioContext = window.AudioContext || window.webkitAudioContext;
const audioCtx = new AudioContext();
const audioBuffers = {};

// Load Sounds
async function loadAudio(name, path) {
  try {
    const response = await fetch(path);
    const arrayBuffer = await response.arrayBuffer();
    audioBuffers[name] = await audioCtx.decodeAudioData(arrayBuffer);
  } catch (e) {
    console.warn(`Failed to load audio: ${path}`, e);
  }
}

function playAudio(name, volume = 0.5) {
  if (audioCtx.state === 'suspended') audioCtx.resume();
  const buffer = audioBuffers[name];
  if (!buffer) return;
  
  const source = audioCtx.createBufferSource();
  source.buffer = buffer;
  
  const gainNode = audioCtx.createGain();
  gainNode.gain.value = volume;
  
  source.connect(gainNode);
  gainNode.connect(audioCtx.destination);
  source.start(0);
}

// Background Animation
const particles = [];
let w, h;

function resizeCanvas() {
  w = canvas.width = window.innerWidth;
  h = canvas.height = window.innerHeight;
}

class Particle {
  constructor() {
    this.reset();
  }
  reset() {
    this.x = Math.random() * w;
    this.y = Math.random() * h;
    this.size = Math.random() * 2;
    this.speedY = Math.random() * 0.5 + 0.1;
    this.opacity = Math.random() * 0.5;
  }
  update() {
    this.y -= this.speedY;
    if (this.y < 0) this.y = h;
  }
  draw() {
    ctx.fillStyle = `rgba(0, 242, 255, ${this.opacity})`;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fill();
  }
}

function initParticles() {
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);
  for(let i=0; i<50; i++) particles.push(new Particle());
  animateParticles();
}

function animateParticles() {
  ctx.clearRect(0, 0, w, h);
  particles.forEach(p => {
    p.update();
    p.draw();
  });
  requestAnimationFrame(animateParticles);
}

// --- Initialization ---

function init() {
  loadAudio('seal', 'seal.mp3');
  loadAudio('jutsu', 'jutsu.mp3');
  initParticles();
  renderGrid();
  setMode('learn');  

  // Resume audio context on first click
  document.body.addEventListener('click', () => {
    if (audioCtx.state === 'suspended') audioCtx.resume();
  }, { once: true });
}

// --- Rendering ---

function renderGrid() {
  grid.innerHTML = '';
  signs.forEach(sign => {
    const btn = document.createElement('button');
    btn.className = 'seal-btn';
    btn.dataset.id = sign.id;

    btn.innerHTML = `
      <img src="${sign.image}" alt="${sign.name}">
      <span>${sign.name.split(' ')[0]}</span>
    `;

    btn.addEventListener('pointerdown', (e) => {
      handleSealInput(sign);
      playAudio('seal', 0.4);
    });

    grid.appendChild(btn);
  });
}

// --- Mode Logic ---

function setMode(mode) {
  currentMode = mode;
  btnLearn.classList.toggle('active', mode === 'learn');
  btnPractice.classList.toggle('active', mode === 'practice');

  if (mode === 'learn') {
    renderLearnInfo(null);
  } else {
    resetPractice();
  }
}

btnLearn.addEventListener('click', () => setMode('learn'));
btnPractice.addEventListener('click', () => setMode('practice'));

// --- Learn Mode ---

function handleSealInput(sign) {
  if (currentMode === 'learn') {
    renderLearnInfo(sign);
  } else if (currentMode === 'practice') {
    handlePracticeInput(sign);
  }
}

function renderLearnInfo(sign) {
  if (!sign) {
    displayArea.innerHTML = `<div class="placeholder-text">Tap a Hand Seal below to learn its secrets.</div>`;
    return;
  }

  displayArea.innerHTML = `
    <div class="info-card">
      <img src="${sign.image}" alt="${sign.name}">
      <div class="info-content">
        <h2>${sign.name}</h2>
        <p>${sign.description}</p>
      </div>
    </div>
  `;
}

// --- Practice Mode ---

function resetPractice() {
  currentSequence = [];
  isComplete = false;
  renderPracticeUI();
}

function handlePracticeInput(sign) {
  if (isComplete) return; 

  currentSequence.push(sign.id);
  const targetId = currentJutsu.sequence[currentSequence.length - 1];

  if (sign.id !== targetId) {
    displayArea.classList.add('shake');
    setTimeout(() => displayArea.classList.remove('shake'), 500);
    currentSequence = [];
  }

  renderPracticeUI();

  if (JSON.stringify(currentSequence) === JSON.stringify(currentJutsu.sequence)) {
    isComplete = true;
    playAudio('jutsu', 0.7);
    renderPracticeUI(true);
  }
}

function renderPracticeUI(success = false) {
  const optionsHtml = jutsus.map(j => 
    `<option value="${j.id}" ${j.id === currentJutsu.id ? 'selected' : ''}>${j.name}</option>`
  ).join('');

  let seqHtml = '';
  currentJutsu.sequence.forEach((reqId, index) => {
    const inputId = currentSequence[index];
    const signData = signs.find(s => s.id === reqId);
    let classes = 'seq-node';
    if (inputId) classes += ' active';
    if (success) classes += ' success';
    const img = `<img src="${signData.image}">`;
    seqHtml += `<div class="${classes}">${img}</div>`;
  });

  const feedbackText = success ? 'JUTSU ACTIVATED!' : '';

  displayArea.innerHTML = `
    <div class="practice-container">
      <div class="jutsu-header">
        <select id="jutsu-select" class="jutsu-select">
          ${optionsHtml}
        </select>
      </div>
      <div class="practice-desc">${currentJutsu.description}</div>
      <div class="sequence-display">${seqHtml}</div>
      <div class="jutsu-feedback">${feedbackText}</div>
    </div>
  `;

  document.getElementById('jutsu-select').addEventListener('change', (e) => {
    currentJutsu = jutsus.find(j => j.id === e.target.value);
    resetPractice();
  });
}

init();