export const signs = [
  {
    id: 'rat',
    name: 'Rat (Ne)',
    image: 'rat.png',
    description: 'Associated with Shadow Imitation and Fire Release. Represents stealth and fluidity.'
  },
  {
    id: 'ox',
    name: 'Ox (Ushi)',
    image: 'ox.png',
    description: 'Used in many Fire Release techniques. Represents strength and fortitude.'
  },
  {
    id: 'tiger',
    name: 'Tiger (Tora)',
    image: 'tiger.png',
    description: 'The most common seal for Fire and Earth Release. Essential for focusing chakra.'
  },
  {
    id: 'hare',
    name: 'Hare (Usagi)',
    image: 'hare.png',
    description: 'Commonly linked with Wind Release. Represents speed and agility.'
  },
  {
    id: 'dragon',
    name: 'Dragon (Tatsu)',
    image: 'dragon.png',
    description: 'Produces dragon-shaped forms. Used heavily in Water Release jutsus.'
  },
  {
    id: 'serpent',
    name: 'Serpent (Mi)',
    image: 'serpent.png',
    description: 'Associated with Earth, Lightning, and Wood Release. Represents grounding energy.'
  },
  {
    id: 'horse',
    name: 'Horse (Uma)',
    image: 'horse.png',
    description: 'Used in Fire Release techniques like the Fireball Jutsu.'
  },
  {
    id: 'ram',
    name: 'Ram (Hitsuji)',
    image: 'ram.png',
    description: 'Essential for channeling chakra generally. Used in Summoning and Clone jutsus.'
  },
  {
    id: 'monkey',
    name: 'Monkey (Saru)',
    image: 'monkey.png',
    description: 'Critical for Chidori and Rasengan-related shaping. Represents dexterity.'
  },
  {
    id: 'bird',
    name: 'Bird (Tori)',
    image: 'bird.png',
    description: 'Primary seal for Wind Release techniques. Represents flight and sharpness.'
  },
  {
    id: 'dog',
    name: 'Dog (Inu)',
    image: 'dog.png',
    description: 'Used for Ice Release and Binding techniques. Often used by Zabuza and Haku.'
  },
  {
    id: 'boar',
    name: 'Boar (I)',
    image: 'boar.png',
    description: 'Used for Summoning Jutsu. Represents charging energy and impact.'
  }
];

export const jutsus = [
  {
    id: 'chidori',
    name: 'Chidori (Lightning Cutter)',
    sequence: ['ox', 'hare', 'monkey'],
    description: 'A high concentration of lightning chakra around the user\'s hand.',
    style: 'lightning'
  },
  {
    id: 'fireball',
    name: 'Fire Style: Fireball Jutsu',
    sequence: ['serpent', 'ram', 'monkey', 'boar', 'horse', 'tiger'],
    description: 'Expels a massive ball of fire from the mouth.',
    style: 'fire'
  },
  {
    id: 'water_dragon',
    name: 'Water Style: Water Dragon',
    sequence: ['ox', 'monkey', 'hare', 'rat', 'boar', 'bird', 'ox', 'horse', 'bird', 'rat', 'tiger', 'dog', 'tiger', 'serpent', 'ox', 'ram', 'serpent', 'boar', 'ram', 'rat', 'rat', 'monkey', 'bird', 'dragon', 'bird', 'ox', 'horse', 'ram', 'tiger', 'serpent', 'rat', 'monkey', 'hare', 'boar', 'dragon', 'ram', 'rat', 'ox', 'monkey', 'bird', 'rat', 'rat', 'boar', 'bird'],
    description: 'Creates a massive dragon of water to crash into the opponent. The full 44-seal sequence.',
    style: 'water'
  },
  {
    id: 'summoning',
    name: 'Summoning Jutsu',
    sequence: ['boar', 'dog', 'bird', 'monkey', 'ram'],
    description: 'Transports an animal or object to the user\'s location.',
    style: 'summon'
  },
  {
    id: 'phoenix_flower',
    name: 'Fire Style: Phoenix Flower',
    sequence: ['rat', 'tiger', 'dog', 'ox', 'hare', 'tiger'],
    description: 'Unleashes a volley of guided fireballs at the target.',
    style: 'fire'
  },
  {
    id: 'mud_wall',
    name: 'Earth Style: Mud Wall',
    sequence: ['tiger', 'hare', 'boar', 'dog'],
    description: 'Erects a solid earthen wall for defense.',
    style: 'earth'
  },
  {
    id: 'water_shark',
    name: 'Water Style: Water Shark Bullet',
    sequence: ['tiger', 'ox', 'tiger', 'rat', 'dog', 'bird'],
    description: 'Launches a shark-shaped water missile at high speed.',
    style: 'water'
  },
  {
    id: 'great_breakthrough',
    name: 'Wind Style: Great Breakthrough',
    sequence: ['tiger', 'ox', 'dog', 'hare', 'serpent'],
    description: 'Generates a massive gust of wind to repel attacks.',
    style: 'wind'
  },
  {
    id: 'ice_mirrors',
    name: 'Ice Style: Crystal Ice Mirrors',
    sequence: ['serpent', 'rat', 'dragon', 'monkey', 'tiger', 'dog'],
    description: 'Surrounds the enemy with teleportation ice mirrors.',
    style: 'ice'
  }
];