import { initClock, getClockTime, MONTHS, WEEKDAYS, DAYS_PER_MONTH, MONTHS_PER_YEAR, TOTAL_DAYS_PER_YEAR } from './calendar.js';

let clockAPI = null;

function renderMonth(monthIndex) {
  const monthName = MONTHS[monthIndex];
  const monthElement = document.createElement('div');
  monthElement.className = 'month-card';

  // Month header
  const header = document.createElement('div');
  header.className = 'month-header';
  header.innerHTML = `<h2>${monthName}</h2><span class=\"month-number\">Month ${monthIndex + 1}/13</span>`;
  monthElement.appendChild(header);

  // Weekday headers
  const weekdayHeader = document.createElement('div');
  weekdayHeader.className = 'weekday-header';
  WEEKDAYS.forEach(day => {
    const dayLabel = document.createElement('div');
    dayLabel.className = 'weekday-label';
    dayLabel.textContent = day.substring(0, 3);
    weekdayHeader.appendChild(dayLabel);
  });
  monthElement.appendChild(weekdayHeader);

  // Days grid
  const daysGrid = document.createElement('div');
  daysGrid.className = 'days-grid';

  for (let day = 1; day <= DAYS_PER_MONTH; day++) {
    const dayOfYear = monthIndex * DAYS_PER_MONTH + day;
    const weekdayIndex = (dayOfYear - 1) % 7;
    const isWorkDay = [1, 0, 1, 0, 1, 0, 1][weekdayIndex] === 1;

    const dayElement = document.createElement('div');
    dayElement.className = `day-cell ${isWorkDay ? 'work-day' : 'rest-day'}`;
    dayElement.dataset.dayOfYear = dayOfYear;

    const dayNumber = document.createElement('div');
    dayNumber.className = 'day-number';
    dayNumber.textContent = day;

    dayElement.appendChild(dayNumber);

    // Click to jump to this day
    dayElement.addEventListener('click', () => {
      if (clockAPI) {
        const state = clockAPI.getState();
        clockAPI.set(state.year, dayOfYear, state.hour, state.minute);
      }
    });

    daysGrid.appendChild(dayElement);
  }

  monthElement.appendChild(daysGrid);
  return monthElement;
}

function renderVeilDay() {
  const veilElement = document.getElementById('veil-day');
  if (!veilElement) return;

  veilElement.innerHTML = `
    <div class=\"veil-day-content\">
      <div class=\"veil-day-icon\">✦</div>
      <h2>Veil Day</h2>
      <p class=\"veil-day-subtitle\">Day 365 • Festival Day</p>
      <p class=\"veil-day-description\">
        A sacred day outside the normal calendar, celebrating the year's end 
        and the mysteries beyond the mortal realm.
      </p>
    </div>
  `;

  veilElement.addEventListener('click', () => {
    if (clockAPI) {
      const state = clockAPI.getState();
      clockAPI.set(state.year, TOTAL_DAYS_PER_YEAR, state.hour, state.minute);
    }
  });
}

function updateCurrentDay() {
  const state = clockAPI.getState();

  // Update year display
  const yearDisplay = document.getElementById('year-display');
  if (yearDisplay) {
    yearDisplay.textContent = `Year ${state.year}`;
  }

  // Remove previous current-day highlights
  document.querySelectorAll('.day-cell.current-day').forEach(el => {
    el.classList.remove('current-day');
  });

  // Remove veil day highlight
  const veilDay = document.getElementById('veil-day');
  if (veilDay) {
    veilDay.classList.remove('current-day');
  }

  // Highlight current day
  if (state.dayOfYear === TOTAL_DAYS_PER_YEAR) {
    if (veilDay) {
      veilDay.classList.add('current-day');
    }
  } else {
    const currentDayCell = document.querySelector(`[data-day-of-year=\"${state.dayOfYear}\"]`);
    if (currentDayCell) {
      currentDayCell.classList.add('current-day');
      // Scroll into view on mobile
      if (window.innerWidth < 768) {
        currentDayCell.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }
}

function init() {
  // Initialize clock
  clockAPI = initClock('sairon-clock');

  // Render calendar
  const calendarGrid = document.getElementById('calendar-grid');
  if (calendarGrid) {
    for (let i = 0; i < MONTHS_PER_YEAR; i++) {
      calendarGrid.appendChild(renderMonth(i));
    }
  }

  // Render Veil Day
  renderVeilDay();

  // Update current day highlight
  updateCurrentDay();

  // Listen for clock updates
  window.addEventListener('sairon-clock-tick', updateCurrentDay);

  // Handle Back Button in Overlay
  const backBtn = document.querySelector('.back-btn');
  if (backBtn && window.self !== window.top) {
    backBtn.textContent = '← Close Calendar';
    backBtn.href = '#';
    backBtn.addEventListener('click', (e) => {
      e.preventDefault();
      window.parent.postMessage('close-land-overlay', '*');
    });
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}