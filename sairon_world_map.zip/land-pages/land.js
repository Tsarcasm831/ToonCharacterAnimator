import { DEFAULT_MODEL } from '../user-defaults.js';
import { LAND_ICONS } from '../constants.js';

const W = 1018;
const H = 968;

const TEXTURES = [
  'water_texture', 'sand', 'rock', 'ground', 'trees', 'grass', 'snow', 
  'plateauswithclouds', 'bamboojungle', 'tealeaves', 'islandjungle', 'steam', 'flowers'
];

function createDefs() {
  const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
  TEXTURES.forEach(t => {
    const pattern = document.createElementNS('http://www.w3.org/2000/svg', 'pattern');
    pattern.id = `${t}Pattern`;
    pattern.setAttribute('patternUnits', 'userSpaceOnUse');
    pattern.setAttribute('width', '100');
    pattern.setAttribute('height', '100');
    
    const image = document.createElementNS('http://www.w3.org/2000/svg', 'image');
    image.setAttribute('href', `../assets/textures/${t}.png`);
    image.setAttribute('x', '0');
    image.setAttribute('y', '0');
    image.setAttribute('width', '100');
    image.setAttribute('height', '100');
    image.setAttribute('preserveAspectRatio', 'none');
    
    pattern.appendChild(image);
    defs.appendChild(pattern);
  });
  return defs;
}

const fallbackRangers = [
  { code: 'A', name: 'Azura Squad', detail: 'Patrolling borderlines and relay towers.' },
  { code: 'B', name: 'Beacon Team', detail: 'Signals intel and long-range scans.' },
  { code: 'C', name: 'Crimson Watch', detail: 'Shadows operating near waterways.' }
];

const fallbackNinjas = [
  { name: 'Raikiri', detail: 'Seen near canyon ridge checkpoints.', village: 'Unknown origin' },
  { name: 'Silent Gale', detail: 'Expert in soundless infiltration.', village: 'Unknown origin' },
  { name: 'Obsidian Kunoichi', detail: 'Poison specialist with stealth tactics.', village: 'Unknown origin' },
  { name: 'Red Fang', detail: 'Reported around supply convoys.', village: 'Unknown origin' },
  { name: 'Ghost Runner', detail: 'Vanishing after dusk; likely local.', village: 'Unknown origin' }
];

const fallbackFacts = [
  { title: 'Terrain Pulse', detail: 'Rolling landscapes spotted with hideouts. Keep scouts mobile and rotate vantage points every 3 hours.' },
  { title: 'Allied Signals', detail: 'Nearest friendly post is two valleys away. Use blue flares to request backup or evacuation.' },
  { title: 'Supply Notes', detail: 'Rations cached along the northern ridge. Approaching storms may affect access routes.' }
];

function getLandId() {
  const params = new URLSearchParams(window.location.search);
  return params.get('id') || document.body.dataset.landId || null;
}

function normalizeRangers(landName, rangers = []) {
  if (Array.isArray(rangers) && rangers.length > 0) {
    return rangers.map((item, index) => ({
      code: item.code || String.fromCharCode(65 + index),
      name: item.name || `Sentinel ${String.fromCharCode(65 + index)}`,
      detail: item.detail || `Scouting routes near ${landName}.`
    }));
  }

  return fallbackRangers.map((item, index) => ({
    ...item,
    detail: `${item.detail} (${landName})`
  }));
}

function normalizeNinjas(landName, ninjas = []) {
  if (Array.isArray(ninjas) && ninjas.length > 0) {
    return ninjas.map((item) => ({
      name: item.name || 'Unidentified ninja',
      detail: item.detail || `Activity tracked around ${landName}.`,
      village: item.village || 'Unknown origin',
      image: item.image || null
    }));
  }

  return fallbackNinjas.map((item) => ({
    ...item,
    detail: `${item.detail} (${landName})`
  }));
}

function normalizeFacts(landName, facts = [], landDesc = '') {
  if (Array.isArray(facts) && facts.length > 0) {
    return facts.map((item, index) => ({
      title: item.title || `Key fact ${index + 1}`,
      detail: item.detail || `Field intel recorded for ${landName}.`
    }));
  }

  if (landDesc) {
    return [
      { title: 'Report Summary', detail: landDesc },
      ...fallbackFacts.slice(1)
    ];
  }

  return fallbackFacts;
}

function pointInPolygon(point, vs) {
  var x = point[0], y = point[1];
  var inside = false;
  for (var i = 0, j = vs.length - 1; i < vs.length; j = i++) {
    var xi = vs[i][0], yi = vs[i][1];
    var xj = vs[j][0], yj = vs[j][1];
    var intersect = ((yi > y) != (yj > y))
      && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}

function renderList(containerId, items, renderer, emptyMessage, placeholderClass = 'stacked-item') {
  const container = document.getElementById(containerId);
  container.innerHTML = '';

  if (!items || items.length === 0) {
    const placeholder = document.createElement('li');
    placeholder.className = placeholderClass;
    placeholder.textContent = emptyMessage || 'No data available.';
    container.appendChild(placeholder);
    return;
  }

  for (const item of items) {
    container.appendChild(renderer(item));
  }
}

function renderRangers(rangers) {
  renderList(
    'rangerList',
    rangers,
    (item) => {
      const li = document.createElement('li');
      li.className = 'stacked-item';

      const pill = document.createElement('span');
      pill.className = 'pill';
      pill.textContent = item.code || '•';

      const body = document.createElement('div');
      body.className = 'item-body';

      const strong = document.createElement('strong');
      strong.textContent = item.name;

      const span = document.createElement('span');
      span.textContent = item.detail;

      body.appendChild(strong);
      body.appendChild(span);
      li.appendChild(pill);
      li.appendChild(body);

      return li;
    },
    'No ranger teams reported.'
  );
}

function getBingoModalElements() {
  return {
    root: document.getElementById('bingoModal'),
    backdrop: document.getElementById('bingoModalBackdrop'),
    closeBtn: document.getElementById('bingoModalClose'),
    name: document.getElementById('bingoName'),
    village: document.getElementById('bingoVillage'),
    detail: document.getElementById('bingoDetail'),
    image: document.getElementById('bingoImage')
  };
}

function slugifyName(name = '') {
  const slug = name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
  return slug || 'unknown-ninja';
}

function getNinjaImage(item) {
  if (item.image) return item.image;
  return `../assets/characters/${slugifyName(item.name)}.png`;
}

function showBingoModal(item) {
  const modal = getBingoModalElements();
  if (!modal.root) return;

  modal.name.textContent = item.name;
  modal.village.textContent = item.village || 'Unknown origin';
  modal.detail.textContent = item.detail;
  modal.image.src = getNinjaImage(item);
  modal.image.alt = `${item.name} portrait`;

  modal.root.classList.remove('hidden');
  modal.root.setAttribute('aria-hidden', 'false');
}

function hideBingoModal() {
  const modal = getBingoModalElements();
  if (!modal.root) return;

  modal.root.classList.add('hidden');
  modal.root.setAttribute('aria-hidden', 'true');
}

function wireModalEvents() {
  const modal = getBingoModalElements();
  if (!modal.root) return;

  modal.backdrop?.addEventListener('click', hideBingoModal);
  modal.closeBtn?.addEventListener('click', hideBingoModal);
  document.addEventListener('keydown', (evt) => {
    if (evt.key === 'Escape' && !modal.root.classList.contains('hidden')) {
      hideBingoModal();
    }
  });
}

function renderBingoBook(ninjas) {
  renderList(
    'ninjaList',
    ninjas,
    (item) => {
      const li = document.createElement('li');
      li.className = 'check-item bingo-card';
      li.setAttribute('role', 'button');
      li.tabIndex = 0;

      const icon = document.createElement('span');
      icon.className = 'check-icon';

      const body = document.createElement('div');
      body.className = 'item-body';

      const strong = document.createElement('strong');
      strong.textContent = item.name;

      const meta = document.createElement('span');
      meta.className = 'item-meta';
      meta.textContent = item.village || 'Unknown origin';

      const span = document.createElement('span');
      span.textContent = item.detail;

      body.appendChild(strong);
      body.appendChild(meta);
      body.appendChild(span);
      li.appendChild(icon);
      li.appendChild(body);

      const openModal = () => showBingoModal(item);
      li.addEventListener('click', openModal);
      li.addEventListener('keydown', (evt) => {
        if (evt.key === 'Enter' || evt.key === ' ') {
          evt.preventDefault();
          openModal();
        }
      });

      return li;
    },
    'No bingo book records found.',
    'check-item'
  );
}

function renderFacts(facts) {
  const container = document.getElementById('factsGrid');
  container.innerHTML = '';

  if (!facts || facts.length === 0) {
    const placeholder = document.createElement('article');
    placeholder.className = 'detail-card';

    const h3 = document.createElement('h3');
    h3.textContent = 'No intel available';

    const p = document.createElement('p');
    p.textContent = 'Details are missing for this territory.';

    placeholder.appendChild(h3);
    placeholder.appendChild(p);
    container.appendChild(placeholder);
    return;
  }

  for (const fact of facts) {
    const card = document.createElement('article');
    card.className = 'detail-card';

    const h3 = document.createElement('h3');
    h3.textContent = fact.title;

    const p = document.createElement('p');
    p.textContent = fact.detail;

    card.appendChild(h3);
    card.appendChild(p);
    container.appendChild(card);
  }
}

function renderSymbol(landId, symbolText) {
  const symbolEl = document.getElementById('symbolNote');
  const iconPath = LAND_ICONS[landId];

  if (iconPath) {
    symbolEl.innerHTML = '';
    symbolEl.className = ''; // remove placeholder style
    symbolEl.style.background = 'transparent';
    symbolEl.style.border = 'none';
    symbolEl.style.padding = '0';
    
    const img = document.createElement('img');
    img.src = `../${iconPath}`; 
    img.alt = 'Land Insignia';
    img.style.width = '56px';
    img.style.height = '56px';
    img.style.objectFit = 'contain';
    img.style.display = 'block';
    img.style.filter = 'drop-shadow(0 2px 6px rgba(0,0,0,0.4))';
    
    symbolEl.appendChild(img);
  } else {
    symbolEl.textContent = symbolText || 'Land symbol (if available)';
    symbolEl.className = 'symbol-placeholder';
    symbolEl.removeAttribute('style');
  }
}

function renderNotFound() {
  document.getElementById('landName').textContent = 'Land not found';
  document.getElementById('landDesc').textContent = 'We could not locate intel for this territory.';
  renderRangers([]);
  renderBingoBook([]);
  renderFacts([]);
  renderSymbol(null, 'No symbol available');

  const svg = document.getElementById('landSvg');
  svg.innerHTML = '';
  svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
}

function renderLand() {
  const landId = getLandId();
  const land = landId ? DEFAULT_MODEL.lands[landId] : null;

  if (!land) {
    renderNotFound();
    return;
  }

  const landName = land.name || land.id;
  const landDesc = land.desc || '';

  document.getElementById('landName').textContent = landName;
  document.getElementById('landDesc').textContent = landDesc || 'No description available.';
  document.title = land.name || land.id;

  const rangers = normalizeRangers(landName, land.rangers);
  const ninjas = normalizeNinjas(landName, land.ninjaRisks);
  const facts = normalizeFacts(landName, land.facts, landDesc);

  renderRangers(rangers);
  renderBingoBook(ninjas);
  renderFacts(facts);
  renderSymbol(landId, land.symbol);

  const svg = document.getElementById('landSvg');
  svg.innerHTML = '';
  svg.appendChild(createDefs());
  svg.setAttribute('viewBox', `0 0 ${W} ${H}`);

  if (!Array.isArray(land.points) || land.points.length === 0) {
    return;
  }

  const points = land.points
    .map(([x, y]) => [x * W / 100, y * H / 100].join(','))
    .join(' ');
  const color = land.color || '#22d3ee';

  let minX = 100;
  let maxX = 0;
  let minY = 100;
  let maxY = 0;
  for (const [x, y] of land.points) {
    minX = Math.min(minX, x);
    maxX = Math.max(maxX, x);
    minY = Math.min(minY, y);
    maxY = Math.max(maxY, y);
  }

  const width = maxX - minX;
  const height = maxY - minY;
  const padX = width * 0.15;
  const padY = height * 0.15;

  const vbX = Math.max(0, (minX - padX) * W / 100);
  const vbY = Math.max(0, (minY - padY) * H / 100);
  const vbW = Math.min(W, (width + 2 * padX) * W / 100);
  const vbH = Math.min(H, (height + 2 * padY) * H / 100);

  svg.setAttribute('viewBox', `${vbX} ${vbY} ${vbW} ${vbH}`);

  let fill = color;
  let fillOpacity = '0.6';
  
  if (land.texture) {
    fill = `url(#${land.texture}Pattern)`;
    fillOpacity = '0.5';
  }

  const polygon = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
  polygon.setAttribute('class', 'land');
  polygon.setAttribute('points', points);
  polygon.setAttribute('fill', fill);
  polygon.setAttribute('fill-opacity', fillOpacity);
  polygon.setAttribute('stroke', color);

  svg.appendChild(polygon);

  // Render Cities within the land
  const pois = DEFAULT_MODEL.poi || [];
  const citySize = 22; // Scale size for land view
  
  pois.forEach(p => {
    if (p.type !== 'city' && p.type !== 'hidden-village') return;
    if (!pointInPolygon([p.x, p.y], land.points)) return;

    const cx = p.x * W / 100;
    const cy = p.y * H / 100;
    
    let href = '';
    if (p.image) {
      href = `../${p.image}`;
    } else {
      let icon = p.icon;
      if (!icon) {
         if (p.type === 'hidden-village') icon = 'C';
         else if (p.type === 'city') icon = 'B';
         else icon = 'A';
      }
      href = `../assets/icons/${icon}.png`;
    }

    const grp = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    
    const img = document.createElementNS('http://www.w3.org/2000/svg', 'image');
    img.setAttribute('href', href);
    img.setAttribute('x', cx - citySize/2);
    img.setAttribute('y', cy - citySize/2);
    img.setAttribute('width', citySize);
    img.setAttribute('height', citySize);
    img.style.pointerEvents = 'auto';
    img.style.cursor = 'help';
    
    const title = document.createElementNS('http://www.w3.org/2000/svg', 'title');
    title.textContent = p.name;
    
    grp.appendChild(img);
    grp.appendChild(title);
    svg.appendChild(grp);
  });
}

function initBackNavigation() {
  const backBtn = document.getElementById('backBtn');
  if (!backBtn) return;

  // Check if running inside the iframe overlay
  if (window.self !== window.top) {
    backBtn.innerHTML = '← Close Dossier';
    backBtn.href = '#';
    backBtn.addEventListener('click', (e) => {
      e.preventDefault();
      window.parent.postMessage('close-land-overlay', '*');
    });
  }
}

wireModalEvents();
renderLand();
initBackNavigation();
