import { W, H, svg, dLayer, rLayer, pLayer, hLayer, tip, out, $, LAND_ICONS } from './constants.js';
import { MODEL, state, loadData } from './model.js';
import { pct, clamp, screenToPct, mk, download, autosave, clear, preloadImages } from './utils.js';

import { initUI } from './ui.js';
import { drawAll } from './render.js';
import { dumpJSON } from './export-utils.js';
import { updateBrushPanel } from './ui/brush-controls.js';
import { updatePieceView } from './ui/piece-inspector.js';
import { initUnits } from './units.js';

export async function init(){
  initUI();
  await loadData();
  initUnits();

  // Assets are now preloaded via the Start Screen / Loading Screen transition
  
  drawAll();
  dumpJSON();
  updateBrushPanel();
  updatePieceView();
  // Notify UI components that data is ready
  window.dispatchEvent(new CustomEvent('json:updated'));
}
